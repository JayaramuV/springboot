$(document).ready(function(){
    $('button').click(function(){       
    	
    	var region = $("#region").val();		
		var markComplete = $("#markComplete").val();
		
		
		if (region == '' || markComplete == '') {
			alert("Please select region to proceed further.");
		} else if(markComplete == 'true') {	
			
			if(confirm("Are you sure you want to complete all WIM Skill Add tickets for the "+region+" region?")){
				window.location = "/download?region=" + region + "&markComplete="+markComplete;	
			}else{
				return false;
			}
			
					
		}else{
			window.location = "/download?region=" + region + "&markComplete="+markComplete;	
		}
    });
});
