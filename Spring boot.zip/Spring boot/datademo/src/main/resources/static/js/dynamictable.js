$(document).ready(function(){


	$.ajax({
		type : "GET",
		url : "getfiledetails",
		contentType : "application/json; charset=utf-8",
		success : function(result) {
			var arr = jQuery.makeArray(result);
			var previousValue = "";
			var dvTable = $("#dvTable");
			dvTable.html("");
			var table = null;
			var row = null;
			for(var i=0;i<arr.length;i++){
				if(previousValue != arr[i][2].toString()){
					previousValue = arr[i][2].toString();
					
					table = $("<table class=table table-bordered />");
					table[0].border = "1";

					// Get the count of columns.
						var columnCount = customers[0].length;

						row = $(table[0].insertRow(-1));
						row.css('background-color', '#d6d4aa');
						var headerCell = $("<th />");
						headerCell.html(previousValue);
						headerCell.css('width', '40%');
						headerCell.css('text-align', 'center');						
						row.append(headerCell);
						
						headerCell = $("<th/>");
						headerCell.html("Last Updated");
						headerCell.css('width', '30%');
						headerCell.css('text-align', 'center');	
						row.append(headerCell);
						
						headerCell = $("<th/>");
						headerCell.html("Size");
						headerCell.css('width', '30%');
						headerCell.css('text-align', 'center');	
						row.append(headerCell);
						
						headerCell = $("<th/>");
						headerCell.html("Action");
						headerCell.css('width', '30%');
						headerCell.css('text-align', 'center');	
						row.append(headerCell);
						
						dvTable.append(table);
					}
				
						row = $(table[0].insertRow(-1));
						var cell = $("<td />");
						cell.html("<a href=/filedownload?filename="+encodeURI(arr[i][0])+"&filepath="+encodeURI(arr[i][3])+">"+arr[i][0]+"</a>");
						row.append(cell);						
						
						cell = $("<td />");
						cell.html((new Date(arr[i][1])).toLocaleString());
						row.append(cell);
						
						cell = $("<td />");
						cell.html(arr[i][4]);
						row.append(cell);	
						
						cell = $("<td />");
						cell.html("<a href=/deletefile?filename="+encodeURI(arr[i][0])+"><img src=image/delete.png/> </a>");
						row.append(cell);
				}				
			
		},
		error : function(result) {
			console.log(result);
			alert(result.status);
		},
	});
	
	

// Build an array containing Customer records.
var customers = new Array();
customers.push([ "Customer Id", "Last Updated", "Size" ]);
customers.push([ 1, "John Hammond", "United States" ]);
customers.push([ 2, "Mudassar Khan", "India" ]);
customers.push([ 3, "Suzanne Mathews", "France" ]);
customers.push([ 4, "Robert Schidner", "Russia" ]);

// Create a HTML Table element.
var table = $("<table class=table table-bordered />");
table[0].border = "1";

// Get the count of columns.
var columnCount = customers[0].length;

// Add the header row.
var row = $(table[0].insertRow(-1));
for (var i = 0; i < columnCount; i++) {
	var headerCell = $("<th />");
	headerCell.html(customers[0][i]);
	row.append(headerCell);
}

// Add the data rows.
for (var i = 1; i < customers.length; i++) {
	row = $(table[0].insertRow(-1));
	for (var j = 0; j < columnCount; j++) {
		var cell = $("<td />");
		cell.html(customers[i][j]);
		row.append(cell);
	}
}

var dvTable = $("#dvTable");
dvTable.html("");
dvTable.append(table);
});