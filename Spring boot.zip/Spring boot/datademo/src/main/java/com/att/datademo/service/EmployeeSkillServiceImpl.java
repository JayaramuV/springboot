/**
 * 
 */
package com.att.datademo.service;

import java.io.File;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.datademo.dao.EmployeeSkillDetailsDAO;

/**
 * @author sm999b
 *
 */
@Service("employeeSkillService")
@Transactional
public class EmployeeSkillServiceImpl implements EmployeeSkillService {

	@PersistenceContext
    private EntityManager entityManager;
	private DecimalFormat df2 = new DecimalFormat(".##");

	@Override
    public List<Object[]> reteriveEmployeeSkill(String attUID, String regionCode, int markCompleteI) {

        
		List<EmployeeSkillDetailsDAO> empDAOList = new ArrayList<EmployeeSkillDetailsDAO>  ();
		//"login" this is the name of the procedure
        StoredProcedureQuery query = entityManager.createStoredProcedureQuery("usp_wim_export_iwmp_skill_updates"); 

        //Declare the parameters in the same order
        query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(3, Integer.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(4, Integer.class, ParameterMode.IN);
        
//        query.registerStoredProcedureParameter(5, Integer.class, ParameterMode.OUT);
//        query.registerStoredProcedureParameter(6, Integer.class, ParameterMode.OUT);

        //Pass the parameter values
        query.setParameter(1, regionCode);
        query.setParameter(2, attUID);
        query.setParameter(3, markCompleteI);
        query.setParameter(4, 0);

        //Execute query
        query.execute();

        //Get output parameters
//        Integer outCode = (Integer) query.getOutputParameterValue(5);
//        Integer cUID = (Integer) query.getOutputParameterValue(6);
        
        List<Object[]> resultObArray = query.getResultList();
        
        
        

        return resultObArray; //enter your condition
    }

    @Override
	public List<Object[]> getAllCategory() {

		String categoryQuery = "select * from tbl_csg_perf_rpt_categories with(nolock)";
		Query caregoryquery = entityManager.createNativeQuery(categoryQuery);
		List<Object[]> categoryListOB = caregoryquery.getResultList();
		return categoryListOB;
	}

	@Override
	public String insertCategory(String categoryName, String attuID) {

		try {
			String categoryQuery = "Insert into tbl_csg_perf_rpt_categories (category_name, added_by_attuid, added_date) values (?, ?, ?)";
			Query caregoryquery = entityManager.createNativeQuery(categoryQuery);
			caregoryquery.setParameter(1, categoryName);
			caregoryquery.setParameter(2, attuID);
			caregoryquery.setParameter(3, new Timestamp(System.currentTimeMillis()));
			caregoryquery.executeUpdate();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return "Category Inserted Successfully.";
	}

	@Override
	public String insertUploadedFile(Integer catID, String fileName, String directoryPath, String attID) {

		String deleteRecord = "delete from tbl_csg_perf_rpt_files WHERE file_name = ?";
		Query deleteQuery = entityManager.createNativeQuery(deleteRecord);
		deleteQuery.setParameter(1, fileName);
		deleteQuery.executeUpdate();

		String insertFileDetails = "insert into tbl_csg_perf_rpt_files (file_category_id, file_name, directory_path, file_added_by_attuid, file_added_date) "
				+ "values (?, ?, ?, ?, ?)";

		Query fileUploadQuery = entityManager.createNativeQuery(insertFileDetails);
		fileUploadQuery.setParameter(1, catID);
		fileUploadQuery.setParameter(2, fileName);
		fileUploadQuery.setParameter(3, directoryPath);
		fileUploadQuery.setParameter(4, attID);
		fileUploadQuery.setParameter(5, new Timestamp(System.currentTimeMillis()));
		fileUploadQuery.executeUpdate();

		return "File Uploaded Successfully.";
	}
	
	
	@Override
	public String deleteFile(String fileName) {

		String deleteRecord = "delete from tbl_csg_perf_rpt_files WHERE file_name = ?";
		Query deleteQuery = entityManager.createNativeQuery(deleteRecord);
		deleteQuery.setParameter(1, fileName);
		deleteQuery.executeUpdate();

		return "Category Deleted Successfully.";
	}
	

	@Override
	public List<Object[]> getAllFiles() {
		String fileQueryStr = "select sprf.file_name, sprf.file_added_date, cprc.category_name, sprf.directory_path from tbl_csg_perf_rpt_files as sprf with(nolock) join tbl_csg_perf_rpt_categories as cprc on sprf.file_category_id = cprc.cat_id group by category_name, file_name, file_added_date, sprf.directory_path";
		Query fileQuery = entityManager.createNativeQuery(fileQueryStr);
		List<Object[]> fileListOB = fileQuery.getResultList();
		for(int ob=0;ob<fileListOB.size();ob++){
			Object[] objectArr = fileListOB.get(ob);
			Object[] largerArr = Arrays.copyOf(objectArr, 5);
			
			String filelocation = objectArr[3].toString()+objectArr[0].toString();
			File file = new File(filelocation);
			
			if (!file.exists() || !file.isFile())
				largerArr[4] = (Object)("0 MB");			
			
			else if(((double) file.length() / (1024 * 1024)) > 1)
				largerArr[4] = (Object)(df2.format((double) file.length() / (1024 * 1024)) + " MB");
			else if(((double) file.length() / 1024) > 1)
				largerArr[4] = df2.format((double) file.length() / 1024) + "  KB";
			else
				largerArr[4] = df2.format(file.length()) + " Bytes";
			
				fileListOB.remove(ob);
				fileListOB.add(ob,largerArr);
		}
		
		
		return fileListOB;
	}
}
