/**
 * 
 */
package com.att.datademo.service;

import java.util.List;

/**
 * @author sm999b
 *
 */
public interface EmployeeSkillService {

	public List<Object[]> reteriveEmployeeSkill(String attUID, String regionCode, int markCompleteI);
	
	public List<Object[]> getAllCategory();
	
	public String insertCategory(String categoryName, String addedBy);
	
	public String insertUploadedFile(Integer fileCategoryID, String fileName, String directoryPath, String attID);
	
	public List<Object[]> getAllFiles();
	
	public String deleteFile(String fileName);

}
