/**
 * 
 */
package com.att.datademo.dao;

/**
 * @author sm999b 
 * Created Date 03 April 2018
 *
 */
public class EmployeeSkillDetailsDAO {

	/**
	 * 
	 */
	public EmployeeSkillDetailsDAO() {
		// TODO Auto-generated constructor stub
	}
	
	String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCUID() {
		return CUID;
	}
	public void setCUID(String cUID) {
		CUID = cUID;
	}

	String CUID;
	
	String LastName;
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getGroupID() {
		return GroupID;
	}
	public void setGroupID(String groupID) {
		GroupID = groupID;
	}
	public String getAlias() {
		return Alias;
	}
	public void setAlias(String alias) {
		Alias = alias;
	}
	public String getCrew() {
		return Crew;
	}
	public void setCrew(String crew) {
		Crew = crew;
	}
	public String getTimeZone() {
		return TimeZone;
	}
	public void setTimeZone(String timeZone) {
		TimeZone = timeZone;
	}
	public String getPrinter() {
		return Printer;
	}
	public void setPrinter(String printer) {
		Printer = printer;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public String getSupervisor() {
		return Supervisor;
	}
	public void setSupervisor(String supervisor) {
		Supervisor = supervisor;
	}
	public String getGeneralInformation() {
		return GeneralInformation;
	}
	public void setGeneralInformation(String generalInformation) {
		GeneralInformation = generalInformation;
	}
	public String getReportingArea() {
		return ReportingArea;
	}
	public void setReportingArea(String reportingArea) {
		ReportingArea = reportingArea;
	}
	public String getStartArea() {
		return StartArea;
	}
	public void setStartArea(String startArea) {
		StartArea = startArea;
	}
	public String getEndArea() {
		return EndArea;
	}
	public void setEndArea(String endArea) {
		EndArea = endArea;
	}
	public String getDispatchCriteria() {
		return DispatchCriteria;
	}
	public void setDispatchCriteria(String dispatchCriteria) {
		DispatchCriteria = dispatchCriteria;
	}
	public String getLoadFactor() {
		return LoadFactor;
	}
	public void setLoadFactor(String loadFactor) {
		LoadFactor = loadFactor;
	}
	public String getLoadType() {
		return LoadType;
	}
	public void setLoadType(String loadType) {
		LoadType = loadType;
	}
	public String getNumberBulk() {
		return NumberBulk;
	}
	public void setNumberBulk(String numberBulk) {
		NumberBulk = numberBulk;
	}
	public String getExpandSkills() {
		return ExpandSkills;
	}
	public void setExpandSkills(String expandSkills) {
		ExpandSkills = expandSkills;
	}
	public String getExpandTurfs() {
		return ExpandTurfs;
	}
	public void setExpandTurfs(String expandTurfs) {
		ExpandTurfs = expandTurfs;
	}
	public String getContractedTechnician() {
		return ContractedTechnician;
	}
	public void setContractedTechnician(String contractedTechnician) {
		ContractedTechnician = contractedTechnician;
	}
	public String getMoveTurfs() {
		return MoveTurfs;
	}
	public void setMoveTurfs(String moveTurfs) {
		MoveTurfs = moveTurfs;
	}
	public String getPositiveTimeReporting() {
		return PositiveTimeReporting;
	}
	public void setPositiveTimeReporting(String positiveTimeReporting) {
		PositiveTimeReporting = positiveTimeReporting;
	}
	public String getContactType() {
		return ContactType;
	}
	public void setContactType(String contactType) {
		ContactType = contactType;
	}
	public String getContactInformation() {
		return ContactInformation;
	}
	public void setContactInformation(String contactInformation) {
		ContactInformation = contactInformation;
	}
	public String getVehicleID() {
		return VehicleID;
	}
	public void setVehicleID(String vehicleID) {
		VehicleID = vehicleID;
	}
	public String getDriver() {
		return Driver;
	}
	public void setDriver(String driver) {
		Driver = driver;
	}

	String FirstName;
	String GroupID;
	String Alias;
	String Crew;
	String TimeZone;
	String Printer;
	String Type;
	String Supervisor;
	String GeneralInformation;
	String ReportingArea;
	String StartArea;
	String EndArea;
	String DispatchCriteria;
	String LoadFactor;
	String LoadType;
	String NumberBulk;
	String ExpandSkills;
	String ExpandTurfs;
	String ContractedTechnician;
	String MoveTurfs;
	String PositiveTimeReporting;
	String ContactType;
	String ContactInformation;
	String VehicleID;
	String Driver;
	
	
//	
//	spreadsheetAddColumn(s, "ID");
//	spreadsheetSetColumnWidth(s, 1, 10);
//
//	// next are a bunch of columns that are unused but need
//	// to be in the final spreadsheet per the client
//	spreadsheetAddColumn(s, "CUID");
//	spreadsheetAddColumn(s, "LastName");
//	spreadsheetAddColumn(s, "FirstName");
//	spreadsheetAddColumn(s, "GroupID");
//	spreadsheetAddColumn(s, "Alias");
//	spreadsheetAddColumn(s, "Crew");
//	spreadsheetAddColumn(s, "TimeZone");
//	spreadsheetAddColumn(s, "Printer");
//	spreadsheetAddColumn(s, "Type");
//	spreadsheetAddColumn(s, "Supervisor");
//	spreadsheetAddColumn(s, "GeneralInformation");
//	spreadsheetAddColumn(s, "ReportingArea");
//	spreadsheetAddColumn(s, "StartArea");
//	spreadsheetAddColumn(s, "EndArea");
//	spreadsheetAddColumn(s, "DispatchCriteria");
//	spreadsheetAddColumn(s, "LoadFactor");
//	spreadsheetAddColumn(s, "LoadType");
//	spreadsheetAddColumn(s, "NumberBulk");
//	spreadsheetAddColumn(s, "ExpandSkills");
//	spreadsheetAddColumn(s, "ExpandTurfs");
//	spreadsheetAddColumn(s, "ContractedTechnician");
//	spreadsheetAddColumn(s, "MoveTurfs");
//	spreadsheetAddColumn(s, "PositiveTimeReporting");
//	spreadsheetAddColumn(s, "ContactType");
//	spreadsheetAddColumn(s, "ContactInformation");
//	spreadsheetAddColumn(s, "ContactType");
//	spreadsheetAddColumn(s, "ContactInformation");
//	spreadsheetAddColumn(s, "VehicleID");
//	spreadsheetAddColumn(s, "Driver");



}
