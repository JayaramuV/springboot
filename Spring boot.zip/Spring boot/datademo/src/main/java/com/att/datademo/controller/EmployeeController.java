package com.att.datademo.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import org.springframework.web.servlet.view.RedirectView;

import com.att.datademo.service.EmployeeSkillService;
import com.example.demo.excel.MyExcelView;

@RestController
public class EmployeeController {
	
	
	String UPLOADED_FOLDER = FileSystems.getDefault().getPath(".").toAbsolutePath().toString().replaceAll("\\.", "")+"uploadfiles\\";
	
	@Autowired 
	private EmployeeSkillService employeeSkillService;
	

	
	@RequestMapping(path="/employeeData/{id}/{regioncode}", method=RequestMethod.GET)
	public List<Object[]> getEmployeeById(@PathVariable("id") String id, @PathVariable("regioncode") String regionCode){
		return employeeSkillService.reteriveEmployeeSkill(id, regionCode, 0);
	}
	
	@RequestMapping(value = { "/", "/login" }, method = RequestMethod.GET)
	public ModelAndView login() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}

	

	@RequestMapping(value = "/download", method = RequestMethod.GET)
	public ModelAndView download(HttpServletRequest request, HttpServletResponse response, @RequestParam String region,
			@RequestParam String markComplete) {

		System.out.println("region: " + region);
		System.out.println("markComplete: " + markComplete);
		String uid = "sm999b";
		int markCompleteI = markComplete.equals("true") ? 1 : 0;
		
		String fileName = "";
		
		switch (region) {
		case "WS":
			fileName = "WEST";
			break;
		case "MW":
			fileName = "MIDWEST";
			break;
		case "SW":
			fileName = "SOUTHWEST";
			break;
		case "SE":
			fileName = "SOUTHEAST";
			break;
		case "OR":
			fileName = "OUT OF REGION";
			break;
	}

		Date today = new Date();
		fileName = fileName+" Batch file "+ (new SimpleDateFormat("MM_dd_yyyy").format(today));		
		List<Object[]> resultObArray = employeeSkillService.reteriveEmployeeSkill(uid, region, markCompleteI);

		Map<String, Object> model = new HashMap<String, Object>();
		// Sheet Name
		model.put("sheetname", "Region_Result");	
		model.put("resultObArray", resultObArray);
		response.setContentType("application/ms-excel");
		response.setHeader("Content-disposition", "attachment; filename="+fileName+".xlsx");
		return new ModelAndView(new MyExcelView(), model);
	}
	
	@RequestMapping(value="/uploadpage",method = RequestMethod.GET)
	public ModelAndView gotoNextPage(){
		
		List<Object[]> categoryListOB =  employeeSkillService.getAllCategory();
		List<Object[]> filesOB =  employeeSkillService.getAllFiles();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("fileupload");
		modelAndView.addObject("categoryListOB", categoryListOB);		
		modelAndView.addObject("filesOB", filesOB);
		
		return modelAndView;
	}
	
	
	@RequestMapping(value="/getcategory",method = RequestMethod.GET)
	public ModelAndView getcategory(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("fileupload");
		return modelAndView;
	}
	
	@RequestMapping(value="/category",method = RequestMethod.GET)
	public ModelAndView category(){
		ModelAndView modelAndView = new ModelAndView();
		List<Object[]> categoryList = employeeSkillService.getAllCategory();
		modelAndView.addObject("categoryList", categoryList);
		modelAndView.setViewName("category");
		return modelAndView;
	}
	
	@RequestMapping(value="/addcategory",method = RequestMethod.GET)
	public ModelAndView addCategory(@RequestParam("categoryName") String categoryName){
		System.out.println("categoryName: "+categoryName);
		String addedBy = "U108";
		employeeSkillService.insertCategory(categoryName, addedBy);
		ModelAndView modelAndView = new ModelAndView(new RedirectView("category"));
		return modelAndView;
	}
	
	@RequestMapping(value="/getfiledetails",method = RequestMethod.GET)
	public @ResponseBody List<Object[]> getFileDetails(){
		return employeeSkillService.getAllFiles();
	}
	
	
	@RequestMapping(value="/deletefile",method = RequestMethod.GET)
	public ModelAndView deleteCategory(@RequestParam("filename") String fileName){
		employeeSkillService.deleteFile(fileName);
		ModelAndView modelAndView = new ModelAndView(new RedirectView("uploadpage"));
		return modelAndView;
	}
	
	

	@RequestMapping(value= "/upload" , method = RequestMethod.POST)
    public ModelAndView singleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam("fileCategory") Integer fileCategoryID,
                                   ModelAndView redirectAttributes) {
		redirectAttributes = new ModelAndView(new RedirectView("uploadpage"));	
		String attID = "us101";
		String directoryPath = "";
		String fileName = "";
        if (file.isEmpty()) {
        	redirectAttributes.addObject("message", "Please select a file to upload");        	
            return redirectAttributes;
        }
        
        try {
        	
        	File dir = new File(UPLOADED_FOLDER);
        	if(!dir.exists())
        		dir.mkdirs();
        	 
        	directoryPath = UPLOADED_FOLDER;
        	fileName = file.getOriginalFilename();
            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(directoryPath + file.getOriginalFilename());
            Files.write(path, bytes);
            
            employeeSkillService.insertUploadedFile(fileCategoryID, fileName, directoryPath, attID);
            
            redirectAttributes.addObject("message",
                    "You successfully uploaded '" + file.getOriginalFilename() + "'");
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        return redirectAttributes;
    }
	
	@RequestMapping(value= "/filedownload" , method = RequestMethod.GET)
    public StreamingResponseBody getSteamingFile(HttpServletResponse response, @RequestParam("filename") String filename, @RequestParam("filepath") String filePath) throws IOException {

        response.setContentType("APPLICATION/DOWNLOAD");
        response.setHeader("Content-Disposition", "attachment; filename=\""+filename+"\"");
        InputStream inputStream = new FileInputStream(new File(filePath+filename));

        return outputStream -> {
            int nRead;
            byte[] data = new byte[1024];
            while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
                outputStream.write(data, 0, nRead);
            }
            inputStream.close();
        };
    } 

}
