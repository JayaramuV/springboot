package com.example.demo.excel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

public class MyExcelView extends AbstractXlsxView {
	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		List<Object[]> resultFromDBList = (List<Object[]>) model.get("resultObArray");

		
		// VARIABLES REQUIRED IN MODEL
		String sheetName = (String) model.get("sheetname");
		// BUILD DOC
		Sheet sheet = workbook.createSheet(sheetName);
		sheet.setDefaultColumnWidth((short) 12);
		sheet.createFreezePane(1, 1);
		int currentRow = 0;
		int currentColumn = 0;
		// CREATE STYLE FOR HEADER
		CellStyle headerStyle = workbook.createCellStyle();
		Font headerFont = workbook.createFont();
		headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		
		headerStyle.setFont(headerFont);
		headerStyle.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
		headerStyle.setFillPattern(HSSFCellStyle.BORDER_THIN);
		// POPULATE HEADER COLUMNS
		Row headerRow = sheet.createRow(currentRow);

		List<String> columnList = new ArrayList<String>();

		columnList.add("ID");
		columnList.add("CUID");
		columnList.add("LastName");
		columnList.add("FirstName");
		columnList.add("GroupID");
		columnList.add("Alias");
		columnList.add("Crew");
		columnList.add("TimeZone");
		columnList.add("Printer");
		columnList.add("Type");
		columnList.add("Supervisor");
		columnList.add("GeneralInformation");
		columnList.add("ReportingArea");
		columnList.add("StartArea");
		columnList.add("EndArea");
		columnList.add("DispatchCriteria");
		columnList.add("LoadFactor");
		columnList.add("LoadType");
		columnList.add("NumberBulk");
		columnList.add("ExpandSkills");
		columnList.add("ExpandTurfs");
		columnList.add("ContractedTechnician");
		columnList.add("MoveTurfs");
		columnList.add("PositiveTimeReporting");
		columnList.add("ContactType");
		columnList.add("ContactInformation");
		columnList.add("ContactType");

		columnList.add("ContactInformation");
		columnList.add("VehicleID");
		columnList.add("Driver");

		// skill columns
		for (int i = 1; i <= 40; i = i + 1) {
			columnList.add("Skill_" + i);
			columnList.add("Default");
			columnList.add("Alternate");
		}

		// additional unused columns
		columnList.add("AssignmentGroup");

		// turf columns (unused)
		for (int t = 1; t <= 40; t = t + 1) {
			columnList.add("Turf_" + t);
			columnList.add("Default");
			columnList.add("Alternate");
			columnList.add("Move");
		}

		// callout skill columns (unused)
		for (int cs = 1; cs <= 20; cs = cs + 1) {
			columnList.add("Callout_Skill_" + cs);
			columnList.add("Default");
		}

		// callout turf columns (unused)
		for (int ct = 1; ct <= 40; ct = ct + 1) {
			columnList.add("Callout_Turf_" + ct);
			columnList.add("Default");
		}

		for (String header : columnList) {
			HSSFRichTextString text = new HSSFRichTextString(header);
			Cell cell = headerRow.createCell(currentColumn);
			cell.setCellStyle(headerStyle);
			cell.setCellValue(header);
			currentColumn++;
		}

		// POPULATE VALUE ROWS/COLUMNS
		currentRow++;// exclude header
		for (Object[] resultObArr : resultFromDBList) {
			currentColumn = 0;
			Row row = sheet.createRow(currentRow);
			for (Object valueOB : resultObArr) {// used to count number of columns
				String value = valueOB.toString();
				Cell cell = row.createCell(currentColumn);
					cell.setCellValue(value);
					if(currentColumn == 0)
						currentColumn = currentColumn+30;
					else
						currentColumn++;
			}
			currentRow++;
		}
	}
}