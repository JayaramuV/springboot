$(document).ready(function() {
	$('#adduser').click(function() {

		var username = document.getElementById('username').value;
		var password = document.getElementById('password').value;
		var confirmpassword = document.getElementById('conpassword').value;
		if(password != confirmpassword){
			swal("Warning","Password not same.");
			return false;
		}else if(username.trim() == ''){
			swal("Error","Please enter user name.");
			return false;
		}else if(password.trim() == ''){
			swal("Error","Please enter password.");
			return false;
		}else if(confirmpassword.trim() == ''){
			swal("Error","Please enter confirm password.");
			return false;
		}
		
		$.ajax({
			type : "get",
			url : "adduser",
			contentType : "application/json; charset=utf-8",
			data : {
					"username" : username,
					"password" : password
					},
					
			success : function(result) {
				 swal("Success",String(result));
				 window.location.href = "usermanagement";
			},
			error : function(result) {
				 window.location.href = "usermanagement";
			},
		});
		
		
	});
	
	$('#cancel').click(function() {

		document.getElementById('userName').value = '';
		document.getElementById('conKeyword').value = '';
		document.getElementById('pass1').value = '';
		
		
		
	});
	
	
});