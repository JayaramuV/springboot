$(document).ready(function() {
	$('#keywordsave').click(function() {

		var keyword = document.getElementById('userName').value;
		var conkeyword = document.getElementById('conKeyword').value;
		
		 if(keyword.trim() == ''){
			swal("Error","Please Enter Keyword.");
			return false;
		}else if(conkeyword.trim() == ''){
			swal("Error","Please Enter Confirm keyword.");
			return false;
		}else if(keyword != conkeyword){
			swal("Warning","Keyword not same.");
			return false;
		}
		
		$.ajax({
			type : "get",
			url : "savekeyword",
			contentType : "application/json; charset=utf-8",
			data : {
					"keyword" : keyword
					},
					
			success : function(result) {
				 swal("Success",String(result));
			},
			error : function(result) {
				swal("Success",result);
			},
		});
		
		
	});
	
	$('#cancel').click(function() {

		document.getElementById('userName').value = '';
		document.getElementById('conKeyword').value = '';
		document.getElementById('pass1').value = '';
		
		
		
	});
	
	
});