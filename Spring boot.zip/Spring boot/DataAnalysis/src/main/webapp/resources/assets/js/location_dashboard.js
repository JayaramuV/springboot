$(function() {
	$.fn.locationdashboard = function(sellocation) {
		
		var date = new Date();
		var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
		var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
		lastDay.setHours(23,59,59,999);
		
		var startDate = new Date(date.getFullYear()
	            ,date.getMonth()
	            ,date.getDate()
	            ,0,0,0);
		
		var endOfDayDate = new Date(date.getFullYear()
	            ,date.getMonth()
	            ,date.getDate()
	            ,23,59,59);
		
		var lastday = new Date();
		lastday.setMonth(lastday.getMonth() - 1);		
		var lastmonthStartDate = new Date(lastday.getFullYear(), lastday.getMonth(), 1 , 0, 0, 0);
		
		var currentDate =  formatDate(date);
		var monthStartDate =  formatDate(firstDay);
		var monthEndDate =  formatDate(lastDay);
		var dayStartDate = formatDate(startDate);
		var dayEndDate = formatDate(endOfDayDate);
		var lastmonthStartDate = formatDate(lastmonthStartDate);
		var lastmonthCurDate = formatDate(lastday);
		
		
		$.ajax({
			type : "get",
			url : "dashboard/get_sprgo_details/",
			contentType : "application/json; charset=utf-8",
			data : {
					"location" : sellocation,
					"startdate" : monthStartDate,
					"enddate" : monthEndDate, 
					"curdate" : currentDate,
					"daystartdate" : dayStartDate,
					"endofdaydate" : dayEndDate,
					"lastmonthstartdate" : lastmonthStartDate,
					"lastmonthcurdate" : lastmonthCurDate},
					
			success : function(result) {
				console.log(result);
				$('[class^="daterangepicker"]').hide();
				$("#wrapper").html( result );
			},
			error : function(result) {
			},
		});
		
		
		/*
		 * $.ajax({ type : "get", url : "dashboard/get_sprgo_details/",
		 * contentType : "application/json; charset=utf-8", data : {"location" :
		 * sellocation}, success : function(result) { alert('Success'); }, error :
		 * function(result) { console.log(result); }, });
		 * 
		 * 
		 * 
		 * $.ajax({ type : "get", url : "dashboard/get_sprgo_details/",
		 * contentType : "application/json; charset=utf-8", data : {"location" :
		 * sellocation}, success : function(result) { alert('Success'); }, error :
		 * function(result) { console.log(result); }, });
		 * 
		 * 
		 * 
		 * 
		 * $.ajax({ type : "get", url : "dashboard/get_sprgo_details/",
		 * contentType : "application/json; charset=utf-8", data : {"location" :
		 * sellocation}, success : function(result) { alert('Success'); }, error :
		 * function(result) { console.log(result); }, });
		 */
		
		
		
	};
});


function formatDate(date) {
	  var hours = date.getHours();
	  var minutes = date.getMinutes();
	  var seconds = date.getSeconds();
// hours = hours ? hours : 12; // the hour '0' should be '12'
	  minutes = minutes < 10 ? '0'+minutes : minutes;
	  seconds = seconds < 10 ? '0'+seconds : seconds;
	  var strTime = hours + ':' + minutes + ':' +seconds;
	  return date.getFullYear() + "-" + (date.getMonth()+1) + "-" + date.getDate() + " " + strTime;
}


$(document).ready(function() {
	$('#datefilterbtn').click(function() {

		var elem = document.getElementById('reportrange');
	    var TextInsideLi = elem.getElementsByTagName('span');
	    var dateRange = TextInsideLi[0].innerHTML;
	    var splitDates = dateRange.split("-"); 
	    var startRange = splitDates[0];
	    var endRange = splitDates[1];
	    var startRangeDate = new Date(moment(startRange));
	    var endRangeDate = new Date(moment(endRange));
	    endRangeDate.setHours(23,59,59,999);
	    
	    var startRangeTimeStamp =  formatDate(startRangeDate);
		var endRangeTimeStamp =  formatDate(endRangeDate);
		
		var date = new Date();
		var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
		var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
		lastDay.setHours(23,59,59,999);
		
		var startDate = new Date(endRangeDate.getFullYear()
	            ,endRangeDate.getMonth()
	            ,endRangeDate.getDate()
	            ,0,0,0);
		
		var endOfDayDate = new Date(endRangeDate.getFullYear()
	            ,endRangeDate.getMonth()
	            ,endRangeDate.getDate()
	            ,23,59,59);
		
		startRangeDate.setMonth(startRangeDate.getMonth() - 1);	
		endRangeDate.setMonth(endRangeDate.getMonth() - 1);	
		
		var currentDate =  formatDate(new Date(endRangeDate.getFullYear()
	            ,endRangeDate.getMonth()+1
	            ,endRangeDate.getDate()
	            ,0,0,0));
		
		var monthStartDate =  startRangeTimeStamp;
		var monthEndDate =  endRangeTimeStamp;
		
		var dayStartDate = formatDate(startDate);
		var dayEndDate = formatDate(endOfDayDate);
		
		var lastmonthStartDate = formatDate(startRangeDate);
		var lastmonthCurDate = formatDate(endRangeDate);;
		
		$.ajax({
			type : "get",
			url : "dashboard/get_sprgo_details/",
			contentType : "application/json; charset=utf-8",
			data : {
					"location" : 'null',
					"startdate" : monthStartDate,
					"enddate" : monthEndDate, 
					"curdate" : currentDate,
					"daystartdate" : dayStartDate,
					"endofdaydate" : dayEndDate,
					"lastmonthstartdate" : lastmonthStartDate,
					"lastmonthcurdate" : lastmonthCurDate},
					
			success : function(result) {
				console.log(result);
				$("#wrapper").html( result );
			},
			error : function(result) {
			},
		});
		
		
	});
	
	
});


$( window ).load(function() {

	$('#All').click(function() {
		$.fn.locationdashboard('?location=null');
	});

	$('#Coimbatore').click(function() {
		$.fn.locationdashboard('?location=Coimbatore');
	});

	$('#Bhavani').click(function() {
		$.fn.locationdashboard('?location=Bhavani');
	});

	$('#Moolapalayam').click(function() {
		$.fn.locationdashboard('?location=Moolapalayam');
	});

	$('#PerunduraiRoad').click(function() {
		$.fn.locationdashboard('?location=PerunduraiRoad');
	});

	$('#HeadOffice').click(function() {
		$.fn.locationdashboard('?location=HeadOffice');
	});

	$('#Warehouse').click(function() {
		$.fn.locationdashboard('?location=Warehouse');
	});
	
	
    
// console.log(window.location.href + Url.get.location);
//	var currentLocation = Url.get.location;
//	$.fn.locationdashboard(currentLocation)
// window.setTimeout(function() {
// document.location.reload(true);
// }, 60000);
});

Url = {
	    get get(){
	        var vars= {};
	        if(window.location.search.length!==0)
	            window.location.search.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value){
	                key=decodeURIComponent(key);
	                if(typeof vars[key]==="undefined") {vars[key]= decodeURIComponent(value);}
	                else {vars[key]= [].concat(vars[key], decodeURIComponent(value));}
	            });
	        return vars;
	    }
};




