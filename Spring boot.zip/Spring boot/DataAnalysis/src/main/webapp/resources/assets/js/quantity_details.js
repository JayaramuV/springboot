$(function () {
    Highcharts.chart('quantity', {
        chart: {
            type: 'column',
            zoomType : "x",
			panKey : "ctrl"
        },
        title: {
            text: 'Monthly Analysis'
        },
        subtitle: {
            text: 'Source: Quantity'
        },
        xAxis: {
            categories: xAxisCategoriesQuantityArray,
            crosshair: true
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Quantity (N)'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y:.1f} (V)</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: seriesQuantityDataArray
    });
});