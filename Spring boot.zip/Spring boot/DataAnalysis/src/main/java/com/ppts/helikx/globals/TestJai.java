package com.ppts.helikx.globals;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.YearMonth;
import java.util.Calendar;
import java.util.Date;

public class TestJai {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub

//		Calendar cal = Calendar.getInstance();
//		
//		System.out.println("Year: "+cal.get(Calendar.YEAR));
//		System.out.println("MONTH: "+(cal.get(Calendar.MONTH)+1));
//		
//		YearMonth yearMonth = YearMonth.of( cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) ); 
//		LocalDate firstOfMonth = yearMonth.atDay( 1 );
//		LocalDate last = yearMonth.atEndOfMonth();
//		
//		Date date = Date.from(firstOfMonth.atStartOfDay(ZoneId.systemDefault()).toInstant());
//		System.out.println(date);
//		
//		date = Date.from(last.atStartOfDay(ZoneId.systemDefault()).toInstant());
//		System.out.println(date);
		
		
//		JSONArray xAxis = new JSONArray();
//		xAxis.add("Coimbatore");			
//		xAxis.add("Bhavani");			
//		xAxis.add("Head Office");		
//		xAxis.add("Perundurai Road");	
//		xAxis.add("Warehouse");	
//		xAxis.add("Moolapalayam");
//		System.out.println(xAxis);
//		
//		JSONObject jsonOB = new JSONObject();
		
//		Calendar cal = Calendar.getInstance();
//		cal.add(Calendar.MONTH, -1);
//		Date result = cal.getTime();
//		System.out.println("result: "+result);
//		
//		
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		
//		Date lastMonthTodayDate = result;			
//		
//		String lastMonthTodayDateStr = formatter.format(lastMonthTodayDate.getTime());
//		Date lastMonthTodayDateStrTime = formatter.parse(lastMonthTodayDateStr);	
//		
//		System.out.println("lastMonthTodayDateStr: "+lastMonthTodayDateStr);
//		System.out.println("lastMonthTodayDateStrTime: "+new Timestamp(lastMonthTodayDateStrTime.getTime()));
		
//		Double d = 1.029957687E7;
//		
//		String deci = new BigDecimal(d.toString()).stripTrailingZeros().toPlainString();
//		
//		System.out.println(new BigDecimal(d.toString()).stripTrailingZeros().toPlainString());
//		
//		System.out.println(angle(12, 30));
		
		Calendar cal = Calendar.getInstance();
		
		YearMonth yearMonth = YearMonth.of(cal.get(Calendar.YEAR),
				(cal.get(Calendar.MONTH) + 1));

		Timestamp timeStampCurrentMonthStartDate = Globals
				.readMonthStartTimeStamp(yearMonth);
		Timestamp timeStampCurrentMonthEndDate = Globals
				.readMonthEndTimeStamp(yearMonth);
		
		System.out.println("timeStampCurrentMonthStartDate: "+timeStampCurrentMonthStartDate);
		System.out.println("timeStampCurrentMonthEndDate: "+timeStampCurrentMonthEndDate);
		
		
//		JSONArray revenueValue = 
		
//		jsonOB.put("Coimbatore", )
				
		
	}
	
	static double angle(int h, int m) {
	    double hAngle = 0.5D * (h * 60 + m);
	    double mAngle = 6 * m;
	    double angle = Math.abs(hAngle - mAngle);
	    angle = 30 * (h - (m/5)) + (m/2);
	    return angle;
	}

}
