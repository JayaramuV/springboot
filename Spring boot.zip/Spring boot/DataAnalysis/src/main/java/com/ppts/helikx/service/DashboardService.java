/**
 * 
 */
package com.ppts.helikx.service;

import java.util.HashMap;
import java.util.List;

/**
 * @author jayaramu.v
 *
 */

public interface DashboardService {

	public HashMap<String, Object> readDaily_SPRGO_Details(String sellocation,
			String monthStartDate, String monthEndDate);

	public HashMap<String, Object> readMonthly_SPRGO_Details(
			String sellocation, String curMonthStartDate,
			String curMonthEndDate, String lastMonthStartDate,
			String lastMonthCurDate);

	public HashMap<String, Object> readMonthly_SPRGO_PercentDetails(
			String sellocation);

	public HashMap<String, Object> readReveneChartDetails(String sellocation,
			String currentMonthStartDate, String currentMonthEndDate);	

	public HashMap<String, Object> readQuantityChartDetails(String sellocation,
			String currentMonthStartDate, String currentMonthEndDate);

	public HashMap<String, Object> readAllLocationDashBoardDetails(
			String sellocation);
	
	public List<Object[]> readProductByVolume(String sellocation,
			String daystartdate, String endofdaydate);
	
	public List<Object[]> readProductByValue(String sellocation,
			String daystartdate, String endofdaydate);
	
	public String saveKeyword(String keyword);
	public List<Object[]> readKeywordDetails();
	public List<Object[]> readdateDetails(Integer keyid);
	public List<Object[]> readCommentDetails(Integer dataID);
	public List<Object[]> readImageDetails(Integer dataID);
	public List<Object[]> readUserDetails();
	public String addUser(String username, String password);


}
