/**
 * 
 */
package com.ppts.helikx.dao.impl;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.YearMonth;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.ppts.helikx.daoi.DashboardDAOI;
import com.ppts.helikx.globals.Globals;
import com.ppts.helikx.model.Comments;
import com.ppts.helikx.model.Data_details;
import com.ppts.helikx.model.ImageDetails;
import com.ppts.helikx.model.Keyword_details;
import com.ppts.helikx.model.User;
import com.ppts.helikx.util.PropertiesConfigUtil;

/**
 * @author jayaramu.v
 *
 */
@Component
public class DashboardDAOImpl implements DashboardDAOI {

	@Autowired
	SessionFactory sessionFactory;

	@Resource
	Environment propsEnv;

	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@SuppressWarnings("rawtypes")
	@Override
	public HashMap<String, Object> readAllLocationDashBoardDetails(String sellocation) {
		HashMap<String, Object> dashBoardDetailsMap = new HashMap<String, Object>();

		try {

			Session dashboardDetailsSession = sessionFactory.getCurrentSession();
			Calendar cal = Calendar.getInstance();

			DetachedCriteria salesCri = DetachedCriteria.forClass(Data_details.class);
			System.out.println("sellocation: "+sellocation);

			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("keyid", Integer.valueOf(sellocation));
				salesCri.add(condition);
			}

			String todayEndDate = formatter.format(Globals.getEndOfDay(cal.getTime()).getTime());
			String todayStartDate = formatter.format(Globals.getStartOfDay(cal.getTime()).getTime());

			Date startDate = formatter.parse(todayStartDate);

			java.sql.Timestamp timeStampStartDate = new Timestamp(startDate.getTime());

			Date endDate = formatter.parse(todayEndDate);

			java.sql.Timestamp timeStampEndDate = new Timestamp(endDate.getTime());

			System.out.println("timeStampStartDate: " + timeStampStartDate);
			System.out.println("timeStampEndDate: " + timeStampEndDate);

			salesCri.add(Restrictions.between("date", timeStampStartDate, timeStampEndDate));

			ProjectionList proList = Projections.projectionList();

			proList.add(Projections.alias(Projections.sum("likes"), "likes"));
			proList.add(Projections.alias(Projections.sum("comment_count"), "comment_count"));
			proList.add(Projections.alias(Projections.sum("post_count"), "post_count"));

			salesCri.setProjection(proList);

			List dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			Iterator dashboardIt = dashboadResultList.iterator();

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				Double likes = (Double) dashboardArrayOB[0];
				Double comment_count = (Double) dashboardArrayOB[1];
				Double post_count = (Double) dashboardArrayOB[2];
				if(likes == null)
					continue;

				System.out.println("Likes: " + likes);
				System.out.println("comment_count: " + comment_count);
				System.out.println("post_count: " + post_count);

				Long saleUnitL = new Double(likes).longValue();

				dashBoardDetailsMap.put("likes", saleUnitL);
				dashBoardDetailsMap.put("comment_count", Globals.round(comment_count, 0));
				dashBoardDetailsMap.put("post_count", Globals.round(post_count, 0));

			}

			salesCri.setProjection(null);
			salesCri.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);

			salesCri = DetachedCriteria.forClass(Data_details.class);

			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("keyid", Integer.valueOf(sellocation));
				salesCri.add(condition);
			}

			YearMonth yearMonth = YearMonth.of(cal.get(Calendar.YEAR), (cal.get(Calendar.MONTH) + 1));

			java.sql.Timestamp timeStampCurrentMonthStartDate = Globals.readMonthStartTimeStamp(yearMonth);
			java.sql.Timestamp timeStampCurrentMonthEndDate = Globals.readMonthEndTimeStamp(yearMonth);

			salesCri.add(Restrictions.between("date", timeStampCurrentMonthStartDate, timeStampCurrentMonthEndDate));

			proList = Projections.projectionList();

			proList.add(Projections.alias(Projections.sum("likes"), "likes"));
			proList.add(Projections.alias(Projections.sum("comment_count"), "comment_count"));
			proList.add(Projections.alias(Projections.sum("post_count"), "post_count"));

			salesCri.setProjection(proList);

			dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			dashboardIt = dashboadResultList.iterator();

			Double likes = null;
			Double comment = null;
			Double post = null;
			Long currentSaleUnitL = null;

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				likes = (Double) dashboardArrayOB[0];
				comment = (Double) dashboardArrayOB[1];
				post = (Double) dashboardArrayOB[2];

				currentSaleUnitL = new Double(likes).longValue();

				dashBoardDetailsMap.put("Current_Month_Likes", likes);
				dashBoardDetailsMap.put("Current_Month_Comment", Globals.round(comment, 0));
				dashBoardDetailsMap.put("Current_Month_Post", Globals.round(post, 0));
				System.out.println("likes: " + likes);

			}

			salesCri.setProjection(null);
			salesCri.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);

			salesCri = DetachedCriteria.forClass(Data_details.class);
			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("keyid", Integer.valueOf(sellocation));
				salesCri.add(condition);
			}

			yearMonth = YearMonth.of(2016, 12);

			java.sql.Timestamp timeStampLastMonthStartDate = Globals.readMonthStartTimeStamp(yearMonth);
			java.sql.Timestamp timeStampLastMonthEndDate = Globals.readMonthEndTimeStamp(yearMonth);

			Calendar currentCal = Calendar.getInstance();
			currentCal.add(Calendar.MONTH, -1);
			Date lastMonthTodayDate = currentCal.getTime();

			String lastMonthTodayDateStr = formatter.format(lastMonthTodayDate.getTime());
			System.out.println("lastMonthTodayDateStr: " + lastMonthTodayDateStr);
			Date lastMonthTodayDateStrTime = new Timestamp(formatter.parse(lastMonthTodayDateStr).getTime());
			System.out.println("lastMonthTodayDateStr: " + lastMonthTodayDateStr);
			System.out.println("timeStampLastMonthStartDate: " + timeStampLastMonthStartDate);

			salesCri.add(Restrictions.between("date", timeStampLastMonthStartDate, lastMonthTodayDateStrTime));

			proList = Projections.projectionList();

			proList.add(Projections.alias(Projections.sum("likes"), "likes"));
			proList.add(Projections.alias(Projections.sum("comment_count"), "comment_count"));
			proList.add(Projections.alias(Projections.sum("post_count"), "post_count"));

			salesCri.setProjection(proList);

			dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			dashboardIt = dashboadResultList.iterator();

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				Double lastLikes = (Double) dashboardArrayOB[0];
				Double lastComment = (Double) dashboardArrayOB[1];
				Double lastPost = (Double) dashboardArrayOB[2];

				System.out.println("lastLikes: " + lastLikes);
				System.out.println("likes: " + likes);
				System.out.println("lastComment: " + lastComment);
				System.out.println("lastPost: " + lastPost);

				double percentLikes = ((likes - lastLikes) / lastLikes) * 100;
				double percentComment = ((comment - lastComment) / lastComment) * 100;
				double percentPost = ((post - lastPost) / lastPost) * 100;
				System.out.println("percentLikes: " + percentLikes);

				Double percentLikesCount = Globals.round(percentLikes, 2);
				Double percentCommentCount = Globals.round(percentComment, 2);
				Double percentPostCount = Globals.round(percentPost, 2);

				String likesCaretDesign = percentLikesCount < 0 ? "fa-caret-down text-danger"
						: "fa-caret-up text-primary";
				String commentCaretDesign = percentCommentCount < 0 ? "fa-caret-down text-danger"
						: "fa-caret-up text-primary";
				String poCaretDesign = percentPostCount < 0 ? "fa-caret-down text-danger" : "fa-caret-up text-primary";

				dashBoardDetailsMap.put("Percent_Likes", percentLikesCount);
				dashBoardDetailsMap.put("Percent_Comment", percentCommentCount);
				dashBoardDetailsMap.put("Percent_Post", percentPostCount);

				dashBoardDetailsMap.put("Likes_cart", likesCaretDesign);
				dashBoardDetailsMap.put("Comment_cart", commentCaretDesign);
				dashBoardDetailsMap.put("Post_cart", poCaretDesign);
			}

			salesCri.setProjection(null);
			salesCri.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			salesCri = DetachedCriteria.forClass(Data_details.class);

			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("keyid", Integer.valueOf(sellocation));
				salesCri.add(condition);
			}

			proList = Projections.projectionList();
			proList.add(Projections.alias(Projections.sum("likes"), "likes"));

			proList.add(Projections.property("date"), "date");
			proList.add(Projections.property("type"), "type");

			proList.add(Projections.groupProperty("date"));
			proList.add(Projections.groupProperty("type"));

			salesCri.add(Restrictions.between("date", timeStampCurrentMonthStartDate, timeStampCurrentMonthEndDate));
			salesCri.addOrder(Order.asc("date"));
			salesCri.addOrder(Order.asc("type"));

			salesCri.setProjection(proList);

			dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			dashboardIt = dashboadResultList.iterator();

			JSONArray xAxisCategoriesArray = new JSONArray();
			JSONArray locationRevenueArray = new JSONArray();
			JSONObject locationRevenueOb = new JSONObject();
			JSONArray seriesDataArray = new JSONArray();

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				Double likesCount = (Double) dashboardArrayOB[0];
				Timestamp date = (Timestamp) dashboardArrayOB[1];
				String type = (String) dashboardArrayOB[2];
				boolean isDataAvail = false;

				if (!xAxisCategoriesArray.contains(date.toString()))
					xAxisCategoriesArray.add(date.toString());

				for (int arrayNo = 0; arrayNo < seriesDataArray.size(); arrayNo++) {
					JSONObject locationOB = (JSONObject) seriesDataArray.get(arrayNo);
					if (((String) locationOB.get("name")).equalsIgnoreCase(type)) {
						locationRevenueArray = (JSONArray) locationOB.get("data");
						isDataAvail = true;
						break;
					}
				}

				if (!isDataAvail) {
					locationRevenueOb = new JSONObject();
					locationRevenueArray = new JSONArray();
					locationRevenueOb.put("name", type);
					locationRevenueOb.put("data", locationRevenueArray);
					seriesDataArray.add(locationRevenueOb);
				}
				locationRevenueArray.add(likesCount);
			}

			dashBoardDetailsMap.put("xAxisCategoriesArray", xAxisCategoriesArray);
			dashBoardDetailsMap.put("seriesDataArray", seriesDataArray);

			salesCri.setProjection(null);
			salesCri.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			salesCri = DetachedCriteria.forClass(Data_details.class);
			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("keyid", Integer.valueOf(sellocation));
				salesCri.add(condition);
			}

			proList = Projections.projectionList();
			proList.add(Projections.alias(Projections.sum("comment_count"), "comment_count"));

			proList.add(Projections.property("date"), "date");
			proList.add(Projections.property("type"), "type");

			proList.add(Projections.groupProperty("date"));
			proList.add(Projections.groupProperty("type"));

			salesCri.add(Restrictions.between("date", timeStampCurrentMonthStartDate, timeStampCurrentMonthEndDate));
			salesCri.addOrder(Order.asc("date"));
			salesCri.addOrder(Order.asc("type"));

			salesCri.setProjection(proList);

			dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			dashboardIt = dashboadResultList.iterator();

			JSONArray xAxisCategoriesQuantityArray = new JSONArray();
			JSONArray locationQuantityArray = new JSONArray();
			JSONObject locationQuantityOb = new JSONObject();
			JSONArray seriesQuantityDataArray = new JSONArray();

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				Double commentCount = (Double) dashboardArrayOB[0];

				Long commentCountL = new Double(commentCount).longValue();
				Timestamp date = (Timestamp) dashboardArrayOB[1];
				String type = (String) dashboardArrayOB[2];
				boolean isDataAvail = false;

				if (!xAxisCategoriesQuantityArray.contains(date.toString()))
					xAxisCategoriesQuantityArray.add(date.toString());

				for (int arrayNo = 0; arrayNo < seriesQuantityDataArray.size(); arrayNo++) {
					JSONObject locationOB = (JSONObject) seriesQuantityDataArray.get(arrayNo);
					if (((String) locationOB.get("name")).equalsIgnoreCase(type)) {
						locationQuantityArray = (JSONArray) locationOB.get("data");
						isDataAvail = true;
						break;
					}
				}

				if (!isDataAvail) {
					locationQuantityOb = new JSONObject();
					locationQuantityArray = new JSONArray();
					locationQuantityOb.put("name", type);
					locationQuantityOb.put("data", locationQuantityArray);
					seriesQuantityDataArray.add(locationQuantityOb);
				}
				locationQuantityArray.add(commentCountL);
			}

			dashBoardDetailsMap.put("xAxisCategoriesCommentArray", xAxisCategoriesQuantityArray);
			dashBoardDetailsMap.put("seriesCommentDataArray", seriesQuantityDataArray);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dashBoardDetailsMap;
	}

	@Override
	public HashMap<String, Object> readDaily_SPRGO_Details(String sellocation, String todayStartDate,
			String todayEndDate) {

		HashMap<String, Object> dashBoardDetailsMap = new HashMap<String, Object>();
		try {

			Session dashboardDetailsSession = sessionFactory.getCurrentSession();
			Calendar cal = Calendar.getInstance();

			DetachedCriteria salesCri = DetachedCriteria.forClass(Data_details.class);

			// String todayStartDate = formatter.format(Globals.getStartOfDay(
			// cal.getTime()).getTime());
			//
			// String todayEndDate = formatter.format(Globals.getEndOfDay(
			// cal.getTime()).getTime());

			Date startDate = formatter.parse(todayStartDate);
			Date endDate = formatter.parse(todayEndDate);

			Timestamp timeStampStartDate = new Timestamp(startDate.getTime());
			Timestamp timeStampEndDate = new Timestamp(endDate.getTime());

			System.out.println("startDate timeStampStartDate: " + timeStampStartDate);
			System.out.println("todayEndDate timeStampEndDate: " + timeStampEndDate);

			salesCri.add(Restrictions.between("date", timeStampStartDate, timeStampEndDate));

			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.alias(Projections.sum("likes"), "likes"));
			proList.add(Projections.alias(Projections.sum("comment_count"), "comment_count"));
			proList.add(Projections.alias(Projections.sum("post_count"), "post_count"));

			salesCri.setProjection(proList);

			List dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			Iterator dashboardIt = dashboadResultList.iterator();

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				Double likes = (Double) dashboardArrayOB[0];
				Double comment_count = (Double) dashboardArrayOB[1];
				Double post_count = (Double) dashboardArrayOB[2];

				System.out.println("Likes: " + likes);
				System.out.println("comment_count: " + comment_count);
				System.out.println("post_count: " + post_count);

				Long saleUnitL = new Double(likes).longValue();

				dashBoardDetailsMap.put("likes", saleUnitL);
				dashBoardDetailsMap.put("comment_count", Globals.round(comment_count, 0));
				dashBoardDetailsMap.put("post_count", Globals.round(post_count, 0));

			}
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return dashBoardDetailsMap;
	}

	@Override
	public HashMap<String, Object> readMonthly_SPRGO_Details(String sellocation, String curMonthStartDate,
			String curMonthEndDate, String lastMonthStartDate, String lastMonthCurDate) {

		HashMap<String, Object> dashBoardDetailsMap = new HashMap<String, Object>();

		try {
			Session dashboardDetailsSession = sessionFactory.getCurrentSession();

			DetachedCriteria salesCri = DetachedCriteria.forClass(Data_details.class);

			salesCri = DetachedCriteria.forClass(Data_details.class);
			Calendar cal = Calendar.getInstance();

			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("location", sellocation);
				salesCri.add(condition);
			}

			// YearMonth yearMonth = YearMonth.of(cal.get(Calendar.YEAR),
			// (cal.get(Calendar.MONTH) + 1));

			// Timestamp timeStampCurrentMonthStartDate = Globals
			// .readMonthStartTimeStamp(yearMonth);
			// Timestamp timeStampCurrentMonthEndDate = Globals
			// .readMonthEndTimeStamp(yearMonth);

			Date startDate = formatter.parse(curMonthStartDate);
			Date endDate = formatter.parse(curMonthEndDate);

			Timestamp timeStampCurrentMonthStartDate = new Timestamp(startDate.getTime());
			Timestamp timeStampCurrentMonthEndDate = new Timestamp(endDate.getTime());

			salesCri.add(Restrictions.between("date", timeStampCurrentMonthStartDate, timeStampCurrentMonthEndDate));

			ProjectionList proList = Projections.projectionList();

			proList = Projections.projectionList();

			proList.add(Projections.alias(Projections.sum("likes"), "likes"));
			proList.add(Projections.alias(Projections.sum("comment_count"), "comment_count"));
			proList.add(Projections.alias(Projections.sum("post_count"), "post_count"));

			salesCri.setProjection(proList);

			List dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			Iterator dashboardIt = dashboadResultList.iterator();

			Double likes = null;
			Double comment_count = null;
			Double post_count = null;
			Long saleUnitL = null;

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				likes = (Double) dashboardArrayOB[0];
				comment_count = (Double) dashboardArrayOB[1];
				post_count = (Double) dashboardArrayOB[2];

				System.out.println("Likes: " + likes);
				System.out.println("comment_count: " + comment_count);
				System.out.println("post_count: " + post_count);

				saleUnitL = new Double(likes).longValue();

				dashBoardDetailsMap.put("likes", saleUnitL);
				dashBoardDetailsMap.put("comment_count", Globals.round(comment_count, 0));
				dashBoardDetailsMap.put("post_count", Globals.round(post_count, 0));
			}

			salesCri.setProjection(null);
			salesCri.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);

			salesCri = DetachedCriteria.forClass(Data_details.class);
			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("location", sellocation);
				salesCri.add(condition);
			}

			// yearMonth = YearMonth.of(cal.get(Calendar.YEAR),
			// cal.get(Calendar.MONTH));
			//
			// Timestamp timeStampLastMonthStartDate = Globals
			// .readMonthStartTimeStamp(yearMonth);
			// Timestamp timeStampLastMonthEndDate = Globals
			// .readMonthEndTimeStamp(yearMonth);
			//
			// Calendar currentCal = Calendar.getInstance();
			// currentCal.add(Calendar.MONTH, -1);

			Date lastMonthDate = formatter.parse(lastMonthStartDate);
			Date lastMonthCurrentDate = formatter.parse(lastMonthCurDate);

			Timestamp timeStampLastMonthStartDate = new Timestamp(lastMonthDate.getTime());

			// Date lastMonthTodayDate = currentCal.getTime();

			String lastMonthTodayDateStr = formatter.format(lastMonthCurrentDate.getTime());
			Date lastMonthTodayDateStrTime = new Timestamp(formatter.parse(lastMonthTodayDateStr).getTime());

			System.out.println("lastMonthTodayDateStr: " + lastMonthTodayDateStr);
			System.out.println("lastMonthTodayDateStrTime: " + lastMonthTodayDateStrTime);

			salesCri.add(Restrictions.between("date", timeStampLastMonthStartDate, lastMonthTodayDateStrTime));

			proList = Projections.projectionList();

			proList.add(Projections.alias(Projections.sum("likes"), "likes"));
			proList.add(Projections.alias(Projections.sum("comment_count"), "comment_count"));
			proList.add(Projections.alias(Projections.sum("post_count"), "post_count"));
			salesCri.setProjection(proList);

			dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			dashboardIt = dashboadResultList.iterator();

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				Double lastLikes = (Double) dashboardArrayOB[0];
				Double lastcomment = (Double) dashboardArrayOB[1];
				Double lastpost = (Double) dashboardArrayOB[2];

				System.out.println("Likes: " + likes);
				System.out.println("comment_count: " + comment_count);
				System.out.println("post_count: " + post_count);

				Long lastsaleUL = new Double(likes).longValue();

				dashBoardDetailsMap.put("likes", saleUnitL);
				dashBoardDetailsMap.put("comment_count", Globals.round(comment_count, 0));
				dashBoardDetailsMap.put("post_count", Globals.round(post_count, 0));

				double percentSaleUnit = ((likes - lastLikes) / lastLikes) * 100;
				double percentRevenue = ((comment_count - lastcomment) / lastcomment) * 100;
				double percentGrossProfit = ((post_count - lastpost) / lastpost) * 100;

				Double percentProductSale = Globals.round(percentSaleUnit, 2);
				Double percentProductRevenue = Globals.round(percentRevenue, 2);
				Double percentProductGrossProfit = Globals.round(percentGrossProfit, 2);

				System.err.println("percentProductSale: " + percentProductSale);

				String saleUnitCaretDesign = percentProductSale < 0 ? "fa-caret-down text-danger"
						: "fa-caret-up text-primary";
				String revenueCaretDesign = percentProductRevenue < 0 ? "fa-caret-down text-danger"
						: "fa-caret-up text-primary";
				String grossProfitaretDesign = percentProductGrossProfit < 0 ? "fa-caret-down text-danger"
						: "fa-caret-up text-primary";

				dashBoardDetailsMap.put("Percent_SaleUnit", percentProductSale);
				dashBoardDetailsMap.put("Percent_Revenue", percentProductRevenue);
				dashBoardDetailsMap.put("Percent_GrossProfit", percentProductGrossProfit);

				dashBoardDetailsMap.put("SaleUnit_cart", saleUnitCaretDesign);
				dashBoardDetailsMap.put("Revenue_cart", revenueCaretDesign);
				dashBoardDetailsMap.put("GrossProfit_cart", grossProfitaretDesign);
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dashBoardDetailsMap;
	}

	@Override
	public HashMap<String, Object> readMonthly_SPRGO_PercentDetails(String sellocation) {
		return null;
	}

	@Override
	public HashMap<String, Object> readReveneChartDetails(String sellocation, String currentMonthStartDate,
			String currentMonthEndDate) {

		HashMap<String, Object> dashBoardDetailsMap = new HashMap<String, Object>();
		try {
			Session dashboardDetailsSession = sessionFactory.getCurrentSession();

			DetachedCriteria salesCri = DetachedCriteria.forClass(Data_details.class);

			salesCri = DetachedCriteria.forClass(Data_details.class);

			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("location", sellocation);
				salesCri.add(condition);
			}

			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.alias(Projections.sum("likes"), "revenue"));

			// Calendar cal = Calendar.getInstance();
			// YearMonth yearMonth = YearMonth.of(cal.get(Calendar.YEAR),
			// (cal.get(Calendar.MONTH) + 1));

			Date currentMonthStartDateOb = formatter.parse(currentMonthStartDate);
			Date currentMonthEndDateOb = formatter.parse(currentMonthEndDate);

			Timestamp timeStampCurrentMonthStartDate = new Timestamp(currentMonthStartDateOb.getTime());
			Timestamp timeStampCurrentMonthEndDate = new Timestamp(currentMonthEndDateOb.getTime());

			proList.add(Projections.property("date"), "transactiondate");
			proList.add(Projections.property("type"), "type");

			proList.add(Projections.groupProperty("date"));
			proList.add(Projections.groupProperty("type"));

			salesCri.add(Restrictions.between("date", timeStampCurrentMonthStartDate, timeStampCurrentMonthEndDate));
			salesCri.addOrder(Order.asc("date"));
			salesCri.addOrder(Order.asc("type"));

			salesCri.setProjection(proList);

			List dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			Iterator dashboardIt = dashboadResultList.iterator();

			JSONArray xAxisCategoriesArray = new JSONArray();
			JSONArray locationRevenueArray = new JSONArray();
			JSONObject locationRevenueOb = new JSONObject();
			JSONArray seriesDataArray = new JSONArray();

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				Double revenue = (Double) dashboardArrayOB[0];
				Timestamp transactionDate = (Timestamp) dashboardArrayOB[1];
				String location = (String) dashboardArrayOB[2];
				boolean isDataAvail = false;

				if (!xAxisCategoriesArray.contains(transactionDate.toString()))
					xAxisCategoriesArray.add(transactionDate.toString());

				for (int arrayNo = 0; arrayNo < seriesDataArray.size(); arrayNo++) {
					JSONObject locationOB = (JSONObject) seriesDataArray.get(arrayNo);
					if (((String) locationOB.get("name")).equalsIgnoreCase(location)) {
						locationRevenueArray = (JSONArray) locationOB.get("data");
						isDataAvail = true;
						break;
					}
				}

				if (!isDataAvail) {
					locationRevenueOb = new JSONObject();
					locationRevenueArray = new JSONArray();
					locationRevenueOb.put("name", location);
					locationRevenueOb.put("data", locationRevenueArray);
					seriesDataArray.add(locationRevenueOb);
				}
				locationRevenueArray.add(revenue);
			}

			dashBoardDetailsMap.put("xAxisCategoriesArray", xAxisCategoriesArray);
			dashBoardDetailsMap.put("seriesDataArray", seriesDataArray);
			System.out.println("dashBoardDetailsMap: "+dashBoardDetailsMap);
			
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return dashBoardDetailsMap;
	}

	@Override
	public HashMap<String, Object> readQuantityChartDetails(String sellocation, String currentMonthStartDate,
			String currentMonthEndDate) {

		HashMap<String, Object> dashBoardDetailsMap = new HashMap<String, Object>();
		try {
			Session dashboardDetailsSession = sessionFactory.getCurrentSession();

			DetachedCriteria salesCri = DetachedCriteria.forClass(Data_details.class);

			salesCri = DetachedCriteria.forClass(Data_details.class);
			if (sellocation != null && !sellocation.equals("null")) {
				Criterion condition = Restrictions.eq("location", sellocation);
				salesCri.add(condition);
			}

			ProjectionList proList = Projections.projectionList();

			proList.add(Projections.alias(Projections.sum("comment_count"), "comment"));

			proList.add(Projections.property("date"), "date");
			proList.add(Projections.property("type"), "type");

			proList.add(Projections.groupProperty("date"));
			proList.add(Projections.groupProperty("type"));

			Calendar cal = Calendar.getInstance();
			YearMonth yearMonth = YearMonth.of(cal.get(Calendar.YEAR), (cal.get(Calendar.MONTH) + 1));

			Date currentMonthStartDateOb = formatter.parse(currentMonthStartDate);
			Date currentMonthEndDateOb = formatter.parse(currentMonthEndDate);

			Timestamp timeStampCurrentMonthStartDate = new Timestamp(currentMonthStartDateOb.getTime());
			Timestamp timeStampCurrentMonthEndDate = new Timestamp(currentMonthEndDateOb.getTime());

			salesCri.add(Restrictions.between("date", timeStampCurrentMonthStartDate, timeStampCurrentMonthEndDate));
			salesCri.addOrder(Order.asc("date"));
			salesCri.addOrder(Order.asc("type"));

			salesCri.setProjection(proList);

			List dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();
			Iterator dashboardIt = dashboadResultList.iterator();

			JSONArray xAxisCategoriesQuantityArray = new JSONArray();
			JSONArray locationQuantityArray = new JSONArray();
			JSONObject locationQuantityOb = new JSONObject();
			JSONArray seriesQuantityDataArray = new JSONArray();

			while (dashboardIt.hasNext()) {

				Object dashboardArrayOB[] = (Object[]) dashboardIt.next();

				Double quantity = (Double) dashboardArrayOB[0];

				Long quantityL = new Double(quantity).longValue();
				Timestamp transactionDate = (Timestamp) dashboardArrayOB[1];
				String location = (String) dashboardArrayOB[2];
				boolean isDataAvail = false;

				if (!xAxisCategoriesQuantityArray.contains(transactionDate.toString()))
					xAxisCategoriesQuantityArray.add(transactionDate.toString());

				for (int arrayNo = 0; arrayNo < seriesQuantityDataArray.size(); arrayNo++) {
					JSONObject locationOB = (JSONObject) seriesQuantityDataArray.get(arrayNo);
					if (((String) locationOB.get("name")).equalsIgnoreCase(location)) {
						locationQuantityArray = (JSONArray) locationOB.get("data");
						isDataAvail = true;
						break;
					}
				}

				if (!isDataAvail) {
					locationQuantityOb = new JSONObject();
					locationQuantityArray = new JSONArray();
					locationQuantityOb.put("name", location);
					locationQuantityOb.put("data", locationQuantityArray);
					seriesQuantityDataArray.add(locationQuantityOb);
				}
				locationQuantityArray.add(quantityL);
			}

			dashBoardDetailsMap.put("xAxisCategoriesQuantityArray", xAxisCategoriesQuantityArray);
			dashBoardDetailsMap.put("seriesQuantityDataArray", seriesQuantityDataArray);
			System.out.println("dashBoardDetailsMapdashBoardDetailsMap: "+dashBoardDetailsMap);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return dashBoardDetailsMap;
	}

	@Override
	public List<Object[]> readProductByVolume(String sellocation, String daystartdate, String endofdaydate) {

		Session proSession = sessionFactory.getCurrentSession();

		Set<String> locationConditionSet = new HashSet<String>();
		if (sellocation == null || "null".equalsIgnoreCase(sellocation)) {
			Criteria productCre = proSession.createCriteria(Data_details.class);
			productCre.setProjection(Projections.distinct(Projections.property("type")));
			List<String> proDetailsList = productCre.list();
			for (String proDetails : proDetailsList)
				locationConditionSet.add(proDetails);
		} else
			locationConditionSet.add(sellocation);

		String productByVolume = propsEnv.getRequiredProperty(PropertiesConfigUtil.product_by_volume);
		SQLQuery proByVolumeQuery = proSession.createSQLQuery(productByVolume);
		proByVolumeQuery.setParameterList("location", locationConditionSet);
		System.out.println("proByVolumeQuery: " + proByVolumeQuery.getQueryString());
		System.out.println("locationConditionSet: " + locationConditionSet);
		List<Object[]> proSaleInfoList = proByVolumeQuery.list();

		for (Object[] proSaleInfoOB : proSaleInfoList) {
			System.out.println("Medicine Name: " + proSaleInfoOB[0]);
			System.out.println("quantity: " + proSaleInfoOB[1]);
			System.out.println("location: " + proSaleInfoOB[2]);
		}
		return proSaleInfoList;
	}

	@Override
	public List<Object[]> readProductByValue(String sellocation, String daystartdate, String endofdaydate) {

		return null;
	}

	@Override
	public List<Object[]> readKeywordDetails() {

		Session dashboardDetailsSession = sessionFactory.getCurrentSession();
		DetachedCriteria salesCri = DetachedCriteria.forClass(Keyword_details.class);

		ProjectionList proList = Projections.projectionList();

		proList.add(Projections.alias(Projections.property("keyid"), "keyid"));
		proList.add(Projections.alias(Projections.property("keyword"), "keyword"));
		proList.add(Projections.alias(Projections.property("create_date"), "date"));
		salesCri.addOrder(Order.asc("keyid"));

		salesCri.setProjection(proList);

		List<Object[]> dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();

		System.out.println("dashboadResultList: " + dashboadResultList.get(0)[0]);
		return dashboadResultList;
	}

	@Override
	public String saveKeyword(String keyword) {

		System.out.println("keyword: " + keyword);

		Session curSession = sessionFactory.getCurrentSession();
		Keyword_details key = new Keyword_details();
		key.setKeyword(keyword);

		key.setCreate_date(new Timestamp(new Date().getTime()));
		curSession.save(key);
		return "Keyword saved successfully.";
	}

	@Override
	public List<Object[]> readdateDetails(Integer keyid) {

		Session dashboardDetailsSession = sessionFactory.getCurrentSession();
		DetachedCriteria salesCri = DetachedCriteria.forClass(Data_details.class);

		Criterion condition = Restrictions.eq("keyid", keyid);
		salesCri.add(condition);
		

		ProjectionList proList = Projections.projectionList();

		proList.add(Projections.alias(Projections.property("data_id"), "data_id"));
		proList.add(Projections.alias(Projections.property("likes"), "likes"));
		proList.add(Projections.alias(Projections.property("comment_count"), "comment"));
		proList.add(Projections.alias(Projections.property("date"), "date"));
		proList.add(Projections.alias(Projections.property("post_count"), "post_count"));
		proList.add(Projections.alias(Projections.property("post_by"), "post_by"));
		proList.add(Projections.alias(Projections.property("type"), "type"));

		salesCri.setProjection(proList);
		salesCri.addOrder(Order.asc("data_id"));

		List<Object[]> dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();

		return dashboadResultList;
	}
 
	@Override
	public List<Object[]> readCommentDetails(Integer dataID) {

		Session dashboardDetailsSession = sessionFactory.getCurrentSession();
		DetachedCriteria salesCri = DetachedCriteria.forClass(Comments.class);
		Criterion condition = Restrictions.eq("data_id", dataID);
		salesCri.add(condition);
		ProjectionList proList = Projections.projectionList();
		

		proList.add(Projections.alias(Projections.property("comment"), "comment"));
		proList.add(Projections.alias(Projections.property("comment_by"), "comment_by"));

		salesCri.setProjection(proList);
		salesCri.addOrder(Order.asc("comment_id"));

		List<Object[]> dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();

		return dashboadResultList;
	}

	@Override
	public List<Object[]> readImageDetails(Integer dataID) {

		Session dashboardDetailsSession = sessionFactory.getCurrentSession();
		DetachedCriteria salesCri = DetachedCriteria.forClass(ImageDetails.class);
		Criterion condition = Restrictions.eq("data_id", dataID);
		salesCri.add(condition);
		ProjectionList proList = Projections.projectionList();
		
		
		proList.add(Projections.alias(Projections.property("img"), "img"));
		proList.add(Projections.alias(Projections.property("img_id"), "img_id"));
		salesCri.setProjection(proList);
		salesCri.addOrder(Order.asc("img_id"));

		List<Object[]> dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();

		return dashboadResultList;
	}
	
	@Override
	public List<Object[]> readUserDetails() {

		Session dashboardDetailsSession = sessionFactory.getCurrentSession();
		DetachedCriteria salesCri = DetachedCriteria.forClass(User.class);
		ProjectionList proList = Projections.projectionList();

		
		proList.add(Projections.alias(Projections.property("name"), "name"));
		proList.add(Projections.alias(Projections.property("createdDate"), "createdDate"));
		salesCri.setProjection(proList);

		List<Object[]> dashboadResultList = salesCri.getExecutableCriteria(dashboardDetailsSession).list();

		return dashboadResultList;
	}
	
	@Override
	public String addUser(String username, String password) {

		Session curSession = sessionFactory.getCurrentSession();
		
		String insertQuery = "insert into helikx_t_user (name, password, enabled, role, date) values "
				+ "('"+username+"','"+password+"','"+true+"',1,'"+new Timestamp(new Date().getTime())+"')";
       curSession.createSQLQuery(insertQuery).executeUpdate();
		
		return "User added successfully.";
	}
}
