///**
// * 
// */
//package com.ppts.helikx.model;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
///**
// * @author jayaramu.v
// *
// */
//@Entity
//@Table(name = "data_details")
//public class ProductDetails {
//
//	private Integer id;
//	private String type;
//	private Integer productcode;
//	
//	@Id
//	@GeneratedValue
//	@Column(name = "data_id")
//	public Integer getId() {
//		return id;
//	}
//	public void setId(Integer id) {
//		this.id = id;
//	}
//	
//	@Column(name = "type")
//	public String getLocation() {
//		return location;
//	}
//	public void setLocation(String location) {
//		this.location = location;
//	}
//	
//	@Column(name = "productcode")
//	public Integer getProductcode() {
//		return productcode;
//	}
//	public void setProductcode(Integer productcode) {
//		this.productcode = productcode;
//	}
//}
