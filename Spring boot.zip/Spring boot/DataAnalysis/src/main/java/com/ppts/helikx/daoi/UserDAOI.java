/**
 * 
 */
package com.ppts.helikx.daoi;

import com.ppts.helikx.model.User;

/**
 * @author jayaramu.v
 *
 */
public interface UserDAOI {

	public User fetchUserDetails(String userName);
	public User readUserDetails();
	
}
