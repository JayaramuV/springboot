/**
 * 
 */
package com.ppts.helikx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author jayaramu.v
 *
 */
@Controller
@RequestMapping("/shopadmin")
public class ShopAdminController {

}
