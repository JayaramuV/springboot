/**
 * 
 */
package com.ppts.helikx.controller;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.json.simple.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ppts.helikx.model.Keyword_details;
import com.ppts.helikx.service.DashboardService;
import com.ppts.helikx.service.UserProcessService;

/**
 * @author jayaramu.v
 *
 */
@Controller
public class LoginNExceptionController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private UserProcessService userProcessService;

	@Autowired
	private DashboardService dashboardService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(ModelAndView model, @RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout, HttpSession session) {

		if (error != null) {
			model.addObject("error", "Invalid username and password!");
		}

		if (logout != null) {
			model.addObject("msg", "You've been logged out successfully.");
		}

		return "login";
	}

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		System.out.println("auth: " + auth);
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}

		return "redirect:/login?logout";

	}

	// for 404 page not found
	@RequestMapping(value = "/404", method = RequestMethod.GET)
	public String pagenotfound() {
		System.out.println("not found");
		return "404";

	}

	// for 404 page not found
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public String accessdenied() {
		return "403";

	}

	@RequestMapping(value = "/alllocation", method = RequestMethod.GET)
	public ModelAndView homeController(ModelAndView locationDashBoardView,
			@RequestParam(value = "location", required = false) String location, HttpSession session) {

		//
		HashMap<String, Object> dashBoardResultMap = dashboardService.readAllLocationDashBoardDetails(location);
		//
		Long likes = (Long) dashBoardResultMap.get("likes");
		Double comment_count = (Double) dashBoardResultMap.get("comment_count");
		Double post_count = (Double) dashBoardResultMap.get("post_count");

		Double currentMonthLikes = (Double) dashBoardResultMap.get("Current_Month_Likes");
		Double currentMonthComment = (Double) dashBoardResultMap.get("Current_Month_Comment");
		Double currentMonthPost = (Double) dashBoardResultMap.get("Current_Month_Post");

		double lastMonthLikePercent = (Double) dashBoardResultMap.get("Percent_Likes");
		double lastMonthCommentPercent = (Double) dashBoardResultMap.get("Percent_Comment");
		double lastMonthcurrentMonthPostPercent = (Double) dashBoardResultMap.get("Percent_Post");

		String likeCaretDesign = (String) dashBoardResultMap.get("Likes_cart");
		String commentCaretDesign = (String) dashBoardResultMap.get("Comment_cart");
		String postaretDesign = (String) dashBoardResultMap.get("Post_cart");

		JSONArray xAxisCategoriesArray = (JSONArray) dashBoardResultMap.get("xAxisCategoriesArray");
		JSONArray seriesDataArray = (JSONArray) dashBoardResultMap.get("seriesDataArray");

		JSONArray xAxisCategoriesQuantityArray = (JSONArray) dashBoardResultMap.get("xAxisCategoriesCommentArray");
		JSONArray seriesQuantityDataArray = (JSONArray) dashBoardResultMap.get("seriesCommentDataArray");

		location = (location == null ? "GigaDeeTs" : (location.equals("null") ? "GigaDeeTs" : location));
		locationDashBoardView.addObject("sellocation", location);

		List<Object[]> keywordDetailsList = dashboardService.readKeywordDetails();
		locationDashBoardView.addObject("keywordDetailsList", keywordDetailsList);

		String currentMonthRevenueStr = new BigDecimal(currentMonthComment.toString()).stripTrailingZeros()
				.toPlainString();
		String currentMonthSaleUnitStr = new BigDecimal(currentMonthLikes.toString()).stripTrailingZeros()
				.toPlainString();
		String currentMonthGrossProfitStr = new BigDecimal(currentMonthPost.toString()).stripTrailingZeros()
				.toPlainString();

		locationDashBoardView.addObject("saleUnit", likes);
		locationDashBoardView.addObject("revenue", comment_count);
		locationDashBoardView.addObject("grossProfit", post_count);

		locationDashBoardView.addObject("currentMonthSaleUnit", currentMonthLikes);
		locationDashBoardView.addObject("currentMonthRevenue", currentMonthComment);
		locationDashBoardView.addObject("currentMonthGrossProfit", currentMonthPost);

		locationDashBoardView.addObject("lastMonthSaleUnitPercent", lastMonthLikePercent);
		locationDashBoardView.addObject("lastMonthcurrentMonthRevenuePercent", lastMonthCommentPercent);
		locationDashBoardView.addObject("lastMonthcurrentMonthGrossProfitPercent", lastMonthcurrentMonthPostPercent);

		locationDashBoardView.addObject("saleUnitCaretDesign", likeCaretDesign);
		locationDashBoardView.addObject("revenueCaretDesign", commentCaretDesign);
		locationDashBoardView.addObject("grossProfitaretDesign", postaretDesign);

		System.out.println("xAxisCategoriesArray: " + xAxisCategoriesArray);
		System.out.println("seriesDataArray: " + seriesDataArray);
		
		locationDashBoardView.addObject("xAxisCategoriesArray", xAxisCategoriesArray);
		locationDashBoardView.addObject("seriesDataArray", seriesDataArray);

		System.out.println("xAxisCategoriesQuantityArray: " + xAxisCategoriesQuantityArray);
		System.out.println("seriesQuantityDataArray: " + seriesQuantityDataArray);
		
		locationDashBoardView.addObject("xAxisCategoriesCommentArray", xAxisCategoriesQuantityArray);
		locationDashBoardView.addObject("seriesCommentDataArray", seriesQuantityDataArray);
		//
		locationDashBoardView.setViewName("dashboard_all_location");
		return locationDashBoardView;
	}

	@RequestMapping(value = "/viewkeydetails", method = RequestMethod.GET)
	public ModelAndView viewKeyDetails(ModelAndView locationDashBoardView,
			@RequestParam(value = "keyid", required = false) String keyid, HttpSession session) {
		System.out.println("keyid: "+keyid);

		String location = "null";
		HashMap<String, Object> dashBoardResultMap = dashboardService.readAllLocationDashBoardDetails(keyid);
		//
		Long likes = (Long) dashBoardResultMap.get("likes");
		Double comment_count = (Double) dashBoardResultMap.get("comment_count");
		Double post_count = (Double) dashBoardResultMap.get("post_count");

		Double currentMonthLikes = (Double) dashBoardResultMap.get("Current_Month_Likes");
		Double currentMonthComment = (Double) dashBoardResultMap.get("Current_Month_Comment");
		Double currentMonthPost = (Double) dashBoardResultMap.get("Current_Month_Post");

		double lastMonthLikePercent = (Double) dashBoardResultMap.get("Percent_Likes");
		double lastMonthCommentPercent = (Double) dashBoardResultMap.get("Percent_Comment");
		double lastMonthcurrentMonthPostPercent = (Double) dashBoardResultMap.get("Percent_Post");

		String likeCaretDesign = (String) dashBoardResultMap.get("Likes_cart");
		String commentCaretDesign = (String) dashBoardResultMap.get("Comment_cart");
		String postaretDesign = (String) dashBoardResultMap.get("Post_cart");

		JSONArray xAxisCategoriesArray = (JSONArray) dashBoardResultMap.get("xAxisCategoriesArray");
		JSONArray seriesDataArray = (JSONArray) dashBoardResultMap.get("seriesDataArray");

		JSONArray xAxisCategoriesQuantityArray = (JSONArray) dashBoardResultMap.get("xAxisCategoriesCommentArray");
		JSONArray seriesQuantityDataArray = (JSONArray) dashBoardResultMap.get("seriesCommentDataArray");

		location = (location == null ? "Social Media" : (location.equals("null") ? "Social Media" : location));
		locationDashBoardView.addObject("sellocation", location);

		List<Object[]> keywordDetailsList = dashboardService.readdateDetails(Integer.valueOf(keyid));
		locationDashBoardView.addObject("keywordDetailsList", keywordDetailsList);

		String currentMonthRevenueStr = new BigDecimal(currentMonthComment.toString()).stripTrailingZeros()
				.toPlainString();
		String currentMonthSaleUnitStr = new BigDecimal(currentMonthLikes.toString()).stripTrailingZeros()
				.toPlainString();
		String currentMonthGrossProfitStr = new BigDecimal(currentMonthPost.toString()).stripTrailingZeros()
				.toPlainString();

		locationDashBoardView.addObject("saleUnit", likes);
		locationDashBoardView.addObject("revenue", comment_count);
		locationDashBoardView.addObject("grossProfit", post_count);

		locationDashBoardView.addObject("currentMonthSaleUnit", currentMonthLikes);
		locationDashBoardView.addObject("currentMonthRevenue", currentMonthComment);
		locationDashBoardView.addObject("currentMonthGrossProfit", currentMonthPost);

		locationDashBoardView.addObject("lastMonthSaleUnitPercent", lastMonthLikePercent);
		locationDashBoardView.addObject("lastMonthcurrentMonthRevenuePercent", lastMonthCommentPercent);
		locationDashBoardView.addObject("lastMonthcurrentMonthGrossProfitPercent", lastMonthcurrentMonthPostPercent);

		locationDashBoardView.addObject("saleUnitCaretDesign", likeCaretDesign);
		locationDashBoardView.addObject("revenueCaretDesign", commentCaretDesign);
		locationDashBoardView.addObject("grossProfitaretDesign", postaretDesign);

		locationDashBoardView.addObject("xAxisCategoriesArray", xAxisCategoriesArray);
		locationDashBoardView.addObject("seriesDataArray", seriesDataArray);

		System.out.println("xAxisCategoriesQuantityArray: " + xAxisCategoriesQuantityArray);

		locationDashBoardView.addObject("xAxisCategoriesCommentArray", xAxisCategoriesQuantityArray);
		locationDashBoardView.addObject("seriesCommentDataArray", seriesQuantityDataArray);
		//
		locationDashBoardView.setViewName("keyworddetails");
		return locationDashBoardView;
	}

	@RequestMapping(value = "/comments", method = RequestMethod.GET)
	public ModelAndView viewComments(ModelAndView keywordView, HttpSession session,
			@RequestParam(value = "dataid", required = false) Integer dataid) {

		List<Object[]> dashBoardResultMap = dashboardService.readCommentDetails(dataid);
		List<Object[]> imageDetailsList = dashboardService.readImageDetails(dataid);

		keywordView.addObject("commentDetailsList", dashBoardResultMap);
		keywordView.addObject("imageDetailsList", imageDetailsList);

		keywordView.setViewName("view_comments");
		return keywordView;
	}

	@RequestMapping(value = "/addkeyword", method = RequestMethod.GET)
	public ModelAndView addkeyword(ModelAndView keywordView, HttpSession session) {

		keywordView.setViewName("add_keyword");
		return keywordView;
	}

	@RequestMapping(value = "/savekeyword", method = RequestMethod.GET)
	@ResponseBody
	public String savekeyword(ModelAndView keywordView, HttpSession session,
			@RequestParam(value = "keyword", required = false) String keyword) {

		return dashboardService.saveKeyword(keyword);
	}

	@RequestMapping(value = "/usermanagement", method = RequestMethod.GET)
	public ModelAndView usermanagement(ModelAndView keywordView, HttpSession session) {
		keywordView.addObject("userdetailsvar", dashboardService.readUserDetails());
		keywordView.setViewName("usermanagement");
		return keywordView;
	}
	
	@RequestMapping(value = "/adduser", method = RequestMethod.GET)
	public String adduser(ModelAndView keywordView, HttpSession session,
			@RequestParam(value = "username", required = false) String username,
			@RequestParam(value = "password", required = false) String password) {
		
		return dashboardService.addUser(username, password);
	}

}
