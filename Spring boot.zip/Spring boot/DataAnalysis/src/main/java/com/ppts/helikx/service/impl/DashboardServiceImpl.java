/**
 * 
 */
package com.ppts.helikx.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ppts.helikx.daoi.DashboardDAOI;
import com.ppts.helikx.service.DashboardService;

/**
 * @author jayaramu.v
 *
 */
@Service
@Transactional
public class DashboardServiceImpl implements DashboardService {

	@Autowired
	private DashboardDAOI dashboardDAOI;

	@Override
	public HashMap<String, Object> readAllLocationDashBoardDetails(
			String sellocation) {
		return dashboardDAOI.readAllLocationDashBoardDetails(sellocation);
	}

	@Override
	public HashMap<String, Object> readMonthly_SPRGO_Details(
			String sellocation, String curMonthStartDate,
			String curMonthEndDate, String lastMonthStartDate,
			String lastMonthCurDate) {

		return dashboardDAOI.readMonthly_SPRGO_Details(sellocation,
				curMonthStartDate, curMonthEndDate, lastMonthStartDate,
				lastMonthCurDate);
	}

	@Override
	public HashMap<String, Object> readMonthly_SPRGO_PercentDetails(
			String sellocation) {
		return dashboardDAOI.readMonthly_SPRGO_PercentDetails(sellocation);
	}

	@Override
	public HashMap<String, Object> readReveneChartDetails(String sellocation,
			String currentMonthStartDate, String currentMonthEndDate) {
		return dashboardDAOI.readReveneChartDetails(sellocation,
				currentMonthStartDate, currentMonthEndDate);
	}

	@Override
	public HashMap<String, Object> readQuantityChartDetails(String sellocation,
			String currentMonthStartDate, String currentMonthEndDate) {
		return dashboardDAOI.readQuantityChartDetails(sellocation,
				currentMonthStartDate, currentMonthEndDate);
	}

	@Override
	public HashMap<String, Object> readDaily_SPRGO_Details(String sellocation,
			String daystartdate, String endofdaydate) {
		return dashboardDAOI.readDaily_SPRGO_Details(sellocation, daystartdate,
				endofdaydate);
	}

	@Override
	public List<Object[]> readProductByVolume(String sellocation,
			String daystartdate, String endofdaydate) {
		return dashboardDAOI.readProductByVolume(sellocation, daystartdate,
				endofdaydate);
	}

	@Override
	public List<Object[]> readProductByValue(String sellocation,
			String daystartdate, String endofdaydate) {

		return dashboardDAOI.readProductByValue(sellocation, daystartdate,
				endofdaydate);
	}

	@Override
	public String saveKeyword(String keyword) {
		
		return  dashboardDAOI.saveKeyword(keyword);
	}

	@Override
	public List<Object[]> readKeywordDetails() {
		// TODO Auto-generated method stub
		return dashboardDAOI.readKeywordDetails();
	}

	@Override
	public List<Object[]> readdateDetails(Integer keyid) {
		return dashboardDAOI.readdateDetails(keyid);
	}

	@Override
	public List<Object[]> readCommentDetails(Integer dataID) {
		return dashboardDAOI.readCommentDetails(dataID);
	}

	@Override
	public List<Object[]> readImageDetails(Integer dataID) {
		return dashboardDAOI.readImageDetails(dataID);
	}

	@Override
	public List<Object[]> readUserDetails() {
		return dashboardDAOI.readUserDetails();
	}

	@Override
	public String addUser(String username, String password) {
		return dashboardDAOI.addUser(username, password);
	}
}
