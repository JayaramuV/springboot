/**
 * 
 */
package com.ppts.helikx.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author jayaramu.v
 *
 */
@Configuration
@ComponentScan({"com.ppts.helikx"})
public class RootConfig {

}
