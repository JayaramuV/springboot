/**
 * 
 */
package com.ppts.helikx.service;

/**
 * @author jayaramu.v
 *
 */
public interface UserProcessService {
	public void readUserDetails();
}
