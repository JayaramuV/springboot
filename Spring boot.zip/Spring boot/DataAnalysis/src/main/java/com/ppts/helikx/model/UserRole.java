/**
 * 
 */
package com.ppts.helikx.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author jayaramu.v
 *
 */
@Entity
@Table(name = "helikx_t_role")
public class UserRole {

	private Integer roleid, role_identity;
	private String role;
	
//	private Set<User> user;

	
	/**
	 * @return the roleid
	 */
	@Id
	@GeneratedValue
	@Column(name = "roleid")
	public Integer getRoleid() {
		return roleid;
	}

	/**
	 * @param roleid
	 *            the roleid to set
	 */
	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}

	/**
	 * @return the role_identity
	 */
	@Column(name = "role_ref", nullable = false, unique = true)
	public Integer getRole_identity() {
		return role_identity;
	}

	/**
	 * @param role_identity
	 *            the role_identity to set
	 */
	public void setRole_identity(Integer role_identity) {
		this.role_identity = role_identity;
	}

	/**
	 * @return the role
	 */
	@Column(name = "role", nullable = true, unique = true, length = 50)
	public String getRole() {
		return role;
	}

	/**
	 * @param role
	 *            the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
//	/**
//	 * @return the user
//	 */
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "helikx_t_role")
//	public Set<User> getUser() {
//		return user;
//	}
//
//	/**
//	 * @param user the user to set
//	 */
//	public void setUser(Set<User> user) {
//		this.user = user;
//	}



}
