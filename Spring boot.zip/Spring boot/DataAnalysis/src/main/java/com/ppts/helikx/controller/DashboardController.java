/**
 * 
 */
package com.ppts.helikx.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ppts.helikx.service.DashboardService;

/**
 * @author jayaramu.v
 *
 */
@Controller
@RequestMapping("/dashboard")
public class DashboardController {

	@Autowired
	private DashboardService dashboardService;

	@RequestMapping(value = "/get_sprgo_details", method = RequestMethod.GET)
	public ModelAndView productSaleInfo(
			ModelAndView locationDashBoardView,
			@RequestParam(value = "location", required = true) String location,
			@RequestParam(value = "startdate", required = false) String monthStartDate,
			@RequestParam(value = "enddate", required = false) String monthEndDate,
			@RequestParam(value = "curdate", required = false) String currentDate,
			@RequestParam(value = "daystartdate", required = false) String daystartdate,
			@RequestParam(value = "endofdaydate", required = false) String endofdaydate,
			@RequestParam(value = "lastmonthstartdate", required = false) String lastmonthstartdate,
			@RequestParam(value = "lastmonthcurdate", required = false) String lastmonthcurdate) {

		System.out.println("location: " + location);
		System.out.println("startdate: " + monthStartDate);
		System.out.println("monthEndDate: " + monthEndDate);
		System.out.println("currentDate: " + currentDate);
		System.out.println("daystartdate: " + daystartdate);
		System.out.println("endofdaydate: " + endofdaydate);
		System.out.println("lastmonthstartdate: " + lastmonthstartdate);
		System.out.println("lastmonthcurdate: " + lastmonthcurdate);

		HashMap<String, Object> dashBoardResultMap = dashboardService
				.readDaily_SPRGO_Details(location, daystartdate, endofdaydate);

		Long saleUnit = (Long) dashBoardResultMap.get("saleUnit");
		Double revenue = (Double) dashBoardResultMap.get("revenue");
		Double grossProfit = (Double) dashBoardResultMap.get("grossProfit");

		dashBoardResultMap = dashboardService.readMonthly_SPRGO_Details(
				location, monthStartDate, monthEndDate, lastmonthstartdate,
				lastmonthcurdate);

		Long currentMonthSaleUnit = (Long) dashBoardResultMap
				.get("Current_Month_SaleUnit");
		Double currentMonthRevenue = (Double) dashBoardResultMap
				.get("Current_Month_Revenue");
		Double currentMonthGrossProfit = (Double) dashBoardResultMap
				.get("Current_Month_GrossProfit");

		double lastMonthSaleUnitPercent = (Double) dashBoardResultMap
				.get("Percent_SaleUnit");
		double lastMonthcurrentMonthRevenuePercent = (Double) dashBoardResultMap
				.get("Percent_Revenue");
		double lastMonthcurrentMonthGrossProfitPercent = (Double) dashBoardResultMap
				.get("Percent_GrossProfit");

		String saleUnitCaretDesign = (String) dashBoardResultMap
				.get("SaleUnit_cart");
		String revenueCaretDesign = (String) dashBoardResultMap
				.get("Revenue_cart");
		String grossProfitaretDesign = (String) dashBoardResultMap
				.get("GrossProfit_cart");

		dashBoardResultMap = dashboardService.readReveneChartDetails(location,
				monthStartDate, monthEndDate);

		JSONArray xAxisCategoriesArray = (JSONArray) dashBoardResultMap
				.get("xAxisCategoriesArray");
		JSONArray seriesDataArray = (JSONArray) dashBoardResultMap
				.get("seriesDataArray");
		
		

//		List<Object[]> productByValueOB = dashboardService.readProductByVolume(
//				location, daystartdate, endofdaydate);

		dashBoardResultMap = dashboardService.readQuantityChartDetails(
				location, monthStartDate, monthEndDate);

		JSONArray xAxisCategoriesQuantityArray = (JSONArray) dashBoardResultMap
				.get("xAxisCategoriesQuantityArray");
		JSONArray seriesQuantityDataArray = (JSONArray) dashBoardResultMap
				.get("seriesQuantityDataArray");

		location = (location == null ? "All Location" : (location
				.equals("null") ? "All Location" : location));
		locationDashBoardView.addObject("sellocation", location);

		String currentMonthRevenueStr = new BigDecimal(
				currentMonthRevenue.toString()).stripTrailingZeros()
				.toPlainString();
		String currentMonthSaleUnitStr = new BigDecimal(
				currentMonthSaleUnit.toString()).stripTrailingZeros()
				.toPlainString();
		String currentMonthGrossProfitStr = new BigDecimal(
				currentMonthGrossProfit.toString()).stripTrailingZeros()
				.toPlainString();

		locationDashBoardView.addObject("saleUnit", saleUnit);
		locationDashBoardView.addObject("revenue", revenue);
		locationDashBoardView.addObject("grossProfit", grossProfit);

		locationDashBoardView.addObject("currentMonthSaleUnit",
				currentMonthSaleUnitStr);
		locationDashBoardView.addObject("currentMonthRevenue",
				currentMonthRevenueStr);
		locationDashBoardView.addObject("currentMonthGrossProfit",
				currentMonthGrossProfitStr);

		locationDashBoardView.addObject("lastMonthSaleUnitPercent",
				lastMonthSaleUnitPercent);
		locationDashBoardView.addObject("lastMonthcurrentMonthRevenuePercent",
				lastMonthcurrentMonthRevenuePercent);
		locationDashBoardView.addObject(
				"lastMonthcurrentMonthGrossProfitPercent",
				lastMonthcurrentMonthGrossProfitPercent);

		locationDashBoardView.addObject("saleUnitCaretDesign",
				saleUnitCaretDesign);
		locationDashBoardView.addObject("revenueCaretDesign",
				revenueCaretDesign);
		locationDashBoardView.addObject("grossProfitaretDesign",
				grossProfitaretDesign);

		locationDashBoardView.addObject("xAxisCategoriesArray",
				xAxisCategoriesArray);
		locationDashBoardView.addObject("seriesDataArray", seriesDataArray);

		locationDashBoardView.addObject("xAxisCategoriesQuantityArray",
				xAxisCategoriesQuantityArray);
		locationDashBoardView.addObject("seriesQuantityDataArray",
				seriesQuantityDataArray);
		
		
		
//		locationDashBoardView.addObject("productByValueOB", productByValueOB);

		locationDashBoardView.setViewName("dashboard_all_location");
		
		

		return locationDashBoardView;
	}
}
