/**
 * 
 */
package com.ppts.helikx.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ppts.helikx.daoi.UserDAOI;
import com.ppts.helikx.service.UserProcessService;

/**
 * @author jayaramu.v
 *
 */
@Service
@Transactional
public class UserProcessServiceImpl implements UserProcessService {

	@Autowired
	private UserDAOI userDao;
	
	@Override
	public void readUserDetails() {
		userDao.readUserDetails();
		
	}

}
