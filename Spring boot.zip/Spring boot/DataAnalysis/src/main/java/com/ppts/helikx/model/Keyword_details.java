/**
 * 
 */
package com.ppts.helikx.model;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Jayaramu
 *
 */
@Entity
@Table(name = "keyword_details")
public class Keyword_details {

	/**
	 * 
	 */
	public Keyword_details() {
	}
	
	
	private int keyid;
	private Integer modified_by;
	private Integer identity;
	
	private String keyword;
	private Timestamp create_date;
	

	private Timestamp modified_date;
	private Timestamp last_modified_date;
	
	private Set<Data_details> keywordDetails = new HashSet<Data_details>();
	
	private User userDetails;
	
	
	
	
	
	/**
	 * @return the keyid
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "keyid")
	public int getKeyid() {
		return keyid;
	}
	/**
	 * @param keyid the keyid to set
	 */
	public void setKeyid(int keyid) {
		this.keyid = keyid;
	}
	
	/**
	 * @return the modified_by
	 */
	@Column(name = "modified_by")
	public Integer getModified_by() {
		return modified_by;
	}
	/**
	 * @param modified_by the modified_by to set
	 */
	public void setModified_by(Integer modified_by) {
		this.modified_by = modified_by;
	}
	/**
	 * @return the identity
	 */
	@Column(name = "identity")
	public Integer getIdentity() {
		return identity;
	}
	/**
	 * @param identity the identity to set
	 */
	public void setIdentity(Integer identity) {
		this.identity = identity;
	}
	/**
	 * @return the keyword
	 */
	@Column(name = "keyword")
	public String getKeyword() {
		return keyword;
	}
	/**
	 * @param keyword the keyword to set
	 */
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	/**
	 * @return the create_date
	 */
	@Column(name = "create_date")
	public Timestamp getCreate_date() {
		return create_date;
	}
	/**
	 * @param create_date the create_date to set
	 */
	public void setCreate_date(Timestamp create_date) {
		this.create_date = create_date;
	}
	/**
	 * @return the modified_date
	 */
	@Column(name = "modified_date")
	public Timestamp getModified_date() {
		return modified_date;
	}
	/**
	 * @param modified_date the modified_date to set
	 */
	public void setModified_date(Timestamp modified_date) {
		this.modified_date = modified_date;
	}
	/**
	 * @return the last_modified_date
	 */
	@Column(name = "last_modified_date")
	public Timestamp getLast_modified_date() {
		return last_modified_date;
	}
	/**
	 * @param last_modified_date the last_modified_date to set
	 */
	public void setLast_modified_date(Timestamp last_modified_date) {
		this.last_modified_date = last_modified_date;
	}
	
	/**
	 * @return the keywordDetails
	 */
	@OneToMany(fetch = FetchType.LAZY)
	public Set<Data_details> getKeywordDetails() {
		return keywordDetails;
	}
	/**
	 * @param keywordDetails the keywordDetails to set
	 */
	public void setKeywordDetails(Set<Data_details> keywordDetails) {
		this.keywordDetails = keywordDetails;
	}
	
	

	

}
