package com.ppts.helikx.config;

import java.util.Properties;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.ppts.helikx.util.PropertiesConfigUtil;

@EnableWebMvc
@Configuration
@ComponentScan({ "com.ppts.helikx" })
@EnableTransactionManagement
@PropertySource("classpath:application.properties")
@Import({ SecurityConfig.class })
@net.bull.javamelody.MonitoredWithGuice
public class AppConfig extends WebMvcConfigurerAdapter {

	@Resource
	Environment propsEnv;

	@Bean(name = "sessionFactory", destroyMethod = "close")
	public SessionFactory hibernatesessionFactory() {
		LocalSessionFactoryBuilder builder = new LocalSessionFactoryBuilder(
				dataSource());
		builder.scanPackages(
				propsEnv.getRequiredProperty(PropertiesConfigUtil.component_scan))
				.addProperties(getHibernateProperties());

		return builder.buildSessionFactory();
	}

	private Properties getHibernateProperties() {
		Properties prop = new Properties();
		prop.put("hibernate.format_sql",
				propsEnv.getRequiredProperty(PropertiesConfigUtil.format_sql));
		prop.put("hibernate.show_sql",
				propsEnv.getRequiredProperty(PropertiesConfigUtil.show_sql));
		prop.put("hibernate.dialect",
				propsEnv.getRequiredProperty(PropertiesConfigUtil.dialect));
		prop.put("hibernate.enable_lazy_load_no_trans", "true");
		return prop;
	}
	

	@Bean(name = "dataSource", destroyMethod = "close")
	public ComboPooledDataSource dataSource() {
		ComboPooledDataSource driverManagerDataSource = new ComboPooledDataSource();
		try {
			driverManagerDataSource.setDriverClass(propsEnv.getProperty(PropertiesConfigUtil.driver_name));
			driverManagerDataSource.setJdbcUrl(propsEnv.getProperty(PropertiesConfigUtil.database_url));
			driverManagerDataSource.setUser(propsEnv.getProperty(PropertiesConfigUtil.user_name));
			driverManagerDataSource.setPassword(propsEnv.getProperty(PropertiesConfigUtil.password));
			driverManagerDataSource.setTestConnectionOnCheckout(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return driverManagerDataSource;
	}
	
	@Bean
	public HibernateTransactionManager getTranscationManager() {
		return new HibernateTransactionManager(hibernatesessionFactory());
	}


	@Bean
	public InternalResourceViewResolver viewResolver() {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/views/");
		viewResolver.setSuffix(".jsp");
		return viewResolver;
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations(
				"/resources/");
		registry.addResourceHandler("**/resources/**").addResourceLocations(
				"/resources/");
	}

}