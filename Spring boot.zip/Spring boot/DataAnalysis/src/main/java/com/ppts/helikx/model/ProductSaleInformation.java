///**
// * 
// */
//package com.ppts.helikx.model;
//
//import java.sql.Timestamp;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
///**
// * @author jayaramu.v
// *
// */
//@Entity
//@Table(name = "data_syn_ds_03")
//public class ProductSaleInformation {
//
//	private Integer id;
//	private String location;
//	private Integer productcode;
//	private Integer saleunit;
//	private Double transactionamount;
//	private Timestamp transactiondate;
//	private Double saleprice;
//	private Double purchaseprice;
//	private Double quantity;
//
//	public ProductSaleInformation() {
//
//	}
//
//	/**
//	 * @return the id
//	 */
//	@Id
//	@GeneratedValue
//	@Column(name = "rownum")
//	public Integer getId() {
//		return id;
//	}
//
//	/**
//	 * @param id
//	 *            the id to set
//	 */
//	public void setId(Integer id) {
//		this.id = id;
//	}
//
//	@Column(name = "location")
//	public String getLocation() {
//		return location;
//	}
//
//	public void setLocation(String location) {
//		this.location = location;
//	}
//
//	@Column(name = "productcode")
//	public Integer getProductcode() {
//		return productcode;
//	}
//
//	public void setProductcode(Integer productcode) {
//		this.productcode = productcode;
//	}
//
//	@Column(name = "saleunit")
//	public Integer getSaleunit() {
//		return saleunit;
//	}
//
//	public void setSaleunit(Integer saleunit) {
//		this.saleunit = saleunit;
//	}
//
//	@Column(name = "transactionamount")
//	public Double getTransactionamount() {
//		return transactionamount;
//	}
//
//	public void setTransactionamount(Double transactionamount) {
//		this.transactionamount = transactionamount;
//	}
//
//	@Column(name = "transactiondate")
//	public Timestamp getTransactiondate() {
//		return transactiondate;
//	}
//
//	public void setTransactiondate(Timestamp transactiondate) {
//		this.transactiondate = transactiondate;
//	}
//
//	@Column(name = "saleprice")
//	public Double getSaleprice() {
//		return saleprice;
//	}
//
//	public void setSaleprice(Double saleprice) {
//		this.saleprice = saleprice;
//	}
//
//	@Column(name = "purchaseprice")
//	public Double getPurchaseprice() {
//		return purchaseprice;
//	}
//
//	public void setPurchaseprice(Double purchaseprice) {
//		this.purchaseprice = purchaseprice;
//	}
//	
//	@Column(name = "quantity")
//	public Double getQuantity() {
//		return quantity;
//	}
//
//	public void setQuantity(Double quantity) {
//		this.quantity = quantity;
//	}
//}
