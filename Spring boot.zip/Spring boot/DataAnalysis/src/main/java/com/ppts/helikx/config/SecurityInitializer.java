/**
 * 
 */
package com.ppts.helikx.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * @author jayaramu.v
 *
 */
public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer {

}
