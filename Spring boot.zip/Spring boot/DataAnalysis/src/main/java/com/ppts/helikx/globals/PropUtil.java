package com.ppts.helikx.globals;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.inject.Singleton;

public class PropUtil {

	private static PropUtil propInstance;

	// Code change Jayaramu 08-07-2016 // Read properties from
	// "spectikproperties.properties" file.
	public String readPropertiesUtil(String propertyName) {

		String propertyFileName = "com/ppts/spectik/sysproperties/spectikproperties.properties";
		Properties prop = new Properties();
		InputStream inputStream = null;
		String propertiesDir = "";
		try {
			inputStream = getClass().getClassLoader().getResourceAsStream(
					propertyFileName);
			if (inputStream != null) {
				prop.load(inputStream);
				propertiesDir = prop.getProperty(propertyName);
			} else {
				throw new FileNotFoundException("property file '"
						+ propertyFileName + "' not found in the classpath");
			}
			// get the property value and print it out
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return propertiesDir;
	}

	@Singleton
	public synchronized static PropUtil getInstance() {
		if (propInstance == null) {
			propInstance = new PropUtil();
		}
		return propInstance;
	}

}
