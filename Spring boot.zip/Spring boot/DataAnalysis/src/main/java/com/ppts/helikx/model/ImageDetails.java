/**
 * 
 */
package com.ppts.helikx.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Jayaramu
 *
 */
@Entity
@Table(name = "image_details")
public class ImageDetails {

	/**
	 * 
	 */
	public ImageDetails() {
		// TODO Auto-generated constructor stub
	}
	

	private int img_id;
	private int data_id;
	
	private String img;
	
	
	/**
	 * @return the img_id
	 */
	@Id
	@GeneratedValue
	@Column(name = "img_id")
	public int getImg_id() {
		return img_id;
	}

	/**
	 * @param img_id the img_id to set
	 */
	public void setImg_id(int img_id) {
		this.img_id = img_id;
	}

	/**
	 * @return the data_id
	 */
	@Column(name = "data_id")
	public int getData_id() {
		return data_id;
	}

	/**
	 * @param data_id the data_id to set
	 */
	public void setData_id(int data_id) {
		this.data_id = data_id;
	}

	/**
	 * @return the img
	 */
	@Column(name = "img")
	public String getImg() {
		return img;
	}

	/**
	 * @param img the img to set
	 */
	public void setImg(String img) {
		this.img = img;
	}

	
	
	
	
}
