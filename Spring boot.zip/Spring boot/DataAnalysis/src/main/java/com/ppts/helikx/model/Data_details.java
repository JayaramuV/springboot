/**
 * 
 */
package com.ppts.helikx.model;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Jayaramu
 *
 */
@Entity
@Table(name = "data_details")
public class Data_details {

	/**
	 * 
	 */
	public Data_details() {
	}
	
	private int data_id;
	private int keyid;
	private Double likes;
	private Double comment_count;
	private Timestamp date;
	private Double post_count;
	
	private String post_by;
	private String type;
	
	private Set<Comments> comments = new HashSet<Comments>();
	private Set<ImageDetails> imageDetails = new HashSet<ImageDetails>();
	

	
	/**
	 * @return the data_id
	 */
	@Id
	@GeneratedValue
	@Column(name = "data_id")
	public int getData_id() {
		return data_id;
	}

	/**
	 * @param data_id the data_id to set
	 */
	public void setData_id(int data_id) {
		this.data_id = data_id;
	}

	/**
	 * @return the type
	 */
	@Column(name = "type")
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the keyid
	 */
	@Column(name = "keyid")
	public int getKeyid() {
		return keyid;
	}

	/**
	 * @param keyid the keyid to set
	 */
	public void setKeyid(int keyid) {
		this.keyid = keyid;
	}

	/**
	 * @return the likes
	 */
	@Column(name = "likes")
	public Double getLikes() {
		return likes;
	}

	/**
	 * @param likes the likes to set
	 */
	public void setLikes(Double likes) {
		this.likes = likes;
	}

	/**
	 * @return the comment_count
	 */
	
	@Column(name = "comment_count")
	public Double getComment_count() {
		return comment_count;
	}

	/**
	 * @param comment_count the comment_count to set
	 */
	public void setComment_count(Double comment_count) {
		this.comment_count = comment_count;
	}

	/**
	 * @return the date
	 */
	@Column(name = "date")
	public Timestamp getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Timestamp date) {
		this.date = date;
	}

	/**
	 * @return the post_count
	 */
	@Column(name = "post_count")
	public Double getPost_count() {
		return post_count;
	}

	/**
	 * @param post_count the post_count to set
	 */
	public void setPost_count(Double post_count) {
		this.post_count = post_count;
	}

	/**
	 * @return the post_by
	 */
	@Column(name = "post_by")
	public String getPost_by() {
		return post_by;
	}

	/**
	 * @param post_by the post_by to set
	 */
	public void setPost_by(String post_by) {
		this.post_by = post_by;
	}
	
	/**
	 * @return the comments
	 */
	@OneToMany(fetch = FetchType.LAZY)
	public Set<Comments> getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(Set<Comments> comments) {
		this.comments = comments;
	}
	
	/**
	 * @return the imageDetails
	 */
	@OneToMany(fetch = FetchType.LAZY)
	public Set<ImageDetails> getImageDetails() {
		return imageDetails;
	}

	/**
	 * @param imageDetails the imageDetails to set
	 */
	public void setImageDetails(Set<ImageDetails> imageDetails) {
		this.imageDetails = imageDetails;
	}



}
