/**
 * 
 */
package com.example.demo.serviceImpl;

import org.springframework.stereotype.Service;

import com.example.demo.dao.BusinessRequestDAO;
import com.example.demo.dao.TeamStatusDetailsDAO;

/**
 * 
 *
 */
@Service("restservice")
public class RestServiceImpl implements RestServiceI {

	@Override
	public TeamStatusDetailsDAO getTeamStatus(String teamID) {
		Integer fts = 5;
		Integer prodTech = 6;
		Integer nonProdTech = 3;
		Integer so = 7;

		TeamStatusDetailsDAO teamStatusDetailsDAO = new TeamStatusDetailsDAO();
		teamStatusDetailsDAO.setFts(fts);
		teamStatusDetailsDAO.setProdTech(prodTech);
		teamStatusDetailsDAO.setNonProdTech(nonProdTech);
		teamStatusDetailsDAO.setSO(so);
		teamStatusDetailsDAO.setTotalTechrptg(fts + prodTech + nonProdTech + so);

		return teamStatusDetailsDAO;

	}
	
	@Override
	public BusinessRequestDAO getVariableDetails(){
		return new BusinessRequestDAO();
	}

}
