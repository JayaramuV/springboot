package com.example.demo.controller;

import javax.ws.rs.PathParam;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.dao.BusinessRequestDAO;
import com.example.demo.dao.TeamStatusDetailsDAO;
import com.example.demo.serviceImpl.RestServiceI;


@Controller
@RequestMapping(value="/api")
public class TeamRestController {

@Autowired
RestServiceI restservice;

	
	@RequestMapping(value="/team/status/{teamid}",method = RequestMethod.GET)
	public @ResponseBody TeamStatusDetailsDAO getLoanDetails(@PathVariable(value = "teamid") String teamid){
		System.out.println("teamid: "+teamid);
		return restservice.getTeamStatus(teamid);		
	}
	@RequestMapping(value="/business",method = RequestMethod.PUT)
	public @ResponseBody BusinessRequestDAO getBusinessVariableDetails(@RequestBody String requestStr){
		JSONParser parser = new JSONParser();
		try {
			JSONObject json = (JSONObject) parser.parse(requestStr);
			
		} catch (ParseException e) {
			e.printStackTrace();
		}	
		
		return restservice.getVariableDetails();
	}
	
	
	
	
}