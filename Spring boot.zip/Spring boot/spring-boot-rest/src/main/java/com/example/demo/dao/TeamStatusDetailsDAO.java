/**
 * 
 */
package com.example.demo.dao;

import java.io.Serializable;


public class TeamStatusDetailsDAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer fts;	
	private Integer prodTech;
	private Integer nonProdTech;
	private Integer SO;
	private Integer totalTechrptg;
	
	/**
	 * @return the fts
	 */
	public Integer getFts() {
		return fts;
	}
	/**
	 * @param fts the fts to set
	 */
	public void setFts(Integer fts) {
		this.fts = fts;
	}
	/**
	 * @return the prodTech
	 */
	public Integer getProdTech() {
		return prodTech;
	}
	/**
	 * @param prodTech the prodTech to set
	 */
	public void setProdTech(Integer prodTech) {
		this.prodTech = prodTech;
	}
	/**
	 * @return the nonProdTech
	 */
	public Integer getNonProdTech() {
		return nonProdTech;
	}
	/**
	 * @param nonProdTech the nonProdTech to set
	 */
	public void setNonProdTech(Integer nonProdTech) {
		this.nonProdTech = nonProdTech;
	}
	/**
	 * @return the sO
	 */
	public Integer getSO() {
		return SO;
	}
	/**
	 * @param sO the sO to set
	 */
	public void setSO(Integer sO) {
		SO = sO;
	}
	/**
	 * @return the totalTechrptg
	 */
	public Integer getTotalTechrptg() {
		return totalTechrptg;
	}
	/**
	 * @param totalTechrptg the totalTechrptg to set
	 */
	public void setTotalTechrptg(Integer totalTechrptg) {
		this.totalTechrptg = totalTechrptg;
	}
	
	

}
