/**
 * 
 */
package com.example.demo.dao;

import java.util.HashMap;

import org.codehaus.jackson.annotate.JsonProperty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * @author Jayaramu
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessRequestDAO {
	
	private String businessKey;
	private boolean withVariablesInReturn = false;
	private String id;
	private String definitionId;
	private String caseInstanceId;
	private boolean ended;
	private boolean suspended;
	private String tenantId;
	
	
	HashMap<String, HashMap<String, HashMap<String, Object>>> responseMap = new HashMap<String, HashMap<String, HashMap<String, Object>>>();
	/**
	 * @return the responseMap
	 */
	
	public HashMap<String, HashMap<String, HashMap<String, Object>>> getResponseMap() {
		return responseMap;
	}







	/**
	 * @param responseMap the responseMap to set
	 */
	public void setResponseMap(HashMap<String, HashMap<String, HashMap<String, Object>>> responseMap) {
		this.responseMap = responseMap;
	}







	
	public BusinessRequestDAO(){
		
		HashMap<String, HashMap<String, HashMap<String, Object>>> responseMap = new HashMap<String, HashMap<String, HashMap<String, Object>>>();
		HashMap<String, HashMap<String, Object>> variMap = new HashMap<String, HashMap<String, Object>>();
		HashMap<String, Object> valueMap = new HashMap<String, Object>();
		ValueInfo valueInfo = new ValueInfo();
		valueMap.put("type","String");
		valueMap.put("value","2018-05-14");
		valueMap.put("valueInfo",valueInfo);
		variMap.put("date",valueMap);
		
		valueMap = new HashMap<String, Object>();
		valueMap.put("type","String");
		valueMap.put("value","10");
		valueMap.put("valueInfo",valueInfo);
		variMap.put("techProd",valueMap);
		
		valueMap = new HashMap<String, Object>();
		valueMap.put("type","String");
		valueMap.put("value","CR4657");
		valueMap.put("valueInfo",valueInfo);
		variMap.put("attUid",valueMap);
		
		
		valueMap = new HashMap<String, Object>();
		valueMap.put("type","String");
		valueMap.put("value","1");
		valueMap.put("valueInfo",valueInfo);
		variMap.put("techNonProd",valueMap);
		
		valueMap = new HashMap<String, Object>();
		valueMap.put("type","String");
		valueMap.put("value","11");
		valueMap.put("valueInfo",valueInfo);
		variMap.put("techCount",valueMap);
		
		valueMap = new HashMap<String, Object>();
		valueMap.put("type","String");
		valueMap.put("value","CR4657");
		valueMap.put("valueInfo",valueInfo);
		variMap.put("supvUid",valueMap);
		
		valueMap = new HashMap<String, Object>();
		valueMap.put("type","String");
		valueMap.put("value","1");
		valueMap.put("valueInfo",valueInfo);
		variMap.put("techSO",valueMap);
		
		valueMap = new HashMap<String, Object>();
		valueMap.put("type","String");
		valueMap.put("value","8");
		valueMap.put("valueInfo",valueInfo);
		variMap.put("techFTE",valueMap);
		
		
		
		
		responseMap.put("variables", variMap);
		setResponseMap(responseMap);
		
		businessKey = "c7da8aed-2e11-11e8-a68b-0a580ae95d22";
		withVariablesInReturn = false;
		id = "37dc84a1-597e-11e8-950e-0a580ae94a95";
		definitionId =  "ed9a76bb-5539-11e8-950e-0a580ae94a95";
		caseInstanceId = null;
		ended = true;
		suspended = false;
		tenantId = null;
	}
	
	
	
	
	
	
	
	/**
	 * @return the businessKey
	 */
	public String getBusinessKey() {
		return businessKey;
	}
	/**
	 * @param businessKey the businessKey to set
	 */
	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}
	/**
	 * @return the withVariablesInReturn
	 */
	public boolean isWithVariablesInReturn() {
		return withVariablesInReturn;
	}
	/**
	 * @param withVariablesInReturn the withVariablesInReturn to set
	 */
	public void setWithVariablesInReturn(boolean withVariablesInReturn) {
		this.withVariablesInReturn = withVariablesInReturn;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the definitionId
	 */
	public String getDefinitionId() {
		return definitionId;
	}
	/**
	 * @param definitionId the definitionId to set
	 */
	public void setDefinitionId(String definitionId) {
		this.definitionId = definitionId;
	}
	/**
	 * @return the caseInstanceId
	 */
	public String getCaseInstanceId() {
		return caseInstanceId;
	}
	/**
	 * @param caseInstanceId the caseInstanceId to set
	 */
	public void setCaseInstanceId(String caseInstanceId) {
		this.caseInstanceId = caseInstanceId;
	}
	/**
	 * @return the ended
	 */
	public boolean isEnded() {
		return ended;
	}
	/**
	 * @param ended the ended to set
	 */
	public void setEnded(boolean ended) {
		this.ended = ended;
	}
	/**
	 * @return the suspended
	 */
	public boolean isSuspended() {
		return suspended;
	}
	/**
	 * @param suspended the suspended to set
	 */
	public void setSuspended(boolean suspended) {
		this.suspended = suspended;
	}
	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}
	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	

}

@JsonTypeName("links")
class Links{
	
	private String method;
	private String href;
	private String rel;
	
	
	/**
	 * @return the method
	 */
	public String getMethod() {
		return method;
	}
	/**
	 * @param method the method to set
	 */
	public void setMethod(String method) {
		this.method = method;
	}
	/**
	 * @return the href
	 */
	public String getHref() {
		return href;
	}
	/**
	 * @param href the href to set
	 */
	public void setHref(String href) {
		this.href = href;
	}
	/**
	 * @return the rel
	 */
	public String getRel() {
		return rel;
	}
	/**
	 * @param rel the rel to set
	 */
	public void setRel(String rel) {
		this.rel = rel;
	}
	
	
}

@JsonTypeName("variables")
class Variables{
	
	public Variables(){		
		
		new Variable("String", "2018-05-14");
	}
	
}

class Variable{
	
	private String type;
	private String value;
	
	Variable(String type, String value){
		this.type = type;
		this.value = value;
	}
	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	
}

@JsonTypeName("valueinfo")
class ValueInfo{
	public ValueInfo(){
		
	}
}
