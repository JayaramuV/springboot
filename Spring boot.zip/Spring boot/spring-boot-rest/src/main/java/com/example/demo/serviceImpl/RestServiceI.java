/**
 * 
 */
package com.example.demo.serviceImpl;

import com.example.demo.dao.BusinessRequestDAO;
import com.example.demo.dao.TeamStatusDetailsDAO;

public interface RestServiceI {

	public TeamStatusDetailsDAO getTeamStatus(String teamID);
	public BusinessRequestDAO getVariableDetails();
}
